--[[--
笔迹光栅化。

两条路子，由开关选择：
  * 普通（美化关）：沿线段画方块，等宽。最省 CPU，作为兜底，也用来读老版本存的笔迹。
  * 美化（默认开）：中心线走二次 B 样条，沿线按弧长撒一串**锥形胶囊**
    （两端半径可以不同的线段）；渲染时逐像素算「到中心线的距离」→ 覆盖率。

这套是照 GoodNotes / Notability 那类笔记软件的公开做法改的：它们都不是把触点直接
连折线，而是「平滑采样点 → 样条插值 → 沿曲线撒笔尖印子」。差别在于手机上有 GPU 能
一次性对整屏像素求距离，Kindle 只有一颗很弱的 CPU，所以这里做了三点裁剪：

  1. **每个像素自己算距离，不查表**。旧实现把圆预生成成一张表、半径量化到 0.25px 一档，
     覆盖率也只量化到 16 档 —— 沿笔画看下去就是一级一级的台阶，也就是用户报的
     **马赛克线条**。现在半径连续、覆盖率 1/64 档（两档之间灰阶差 4/255），
     墨水屏上看不出台阶。
  2. **相邻胶囊共用端点和半径**，天然连成一片：不需要在关节额外补圆去填角，
     也就没有多边形拼接那种接缝、重叠黑斑。
  3. **每帧只画最新的一两段**，绝不在书写时重画整条笔画 —— 笔画越写越长也不会变卡。

关于第 3 点的正确性：抬笔时要记得补 `Ink:finish` 那几段，否则屏幕上会少一小截，
和换页重绘的结果也对不上 —— 这点由调用方负责，见 main.lua / hw_notebook.lua。

性能上有一条硬约束：blitbuffer 的 `setPixelBlend` **不做越界检查**（只有
`setPixelClamped` 做），写越界不会报错而是直接改坏相邻内存。所以每个入口都必须先
把包围盒夹进画布，热路径里则用已经夹过的下标直接调 `setPixel`。

笔画数据结构（纯数字与数组，方便直接存进 sidecar）：
    stroke = { n = 点数, w = 笔宽, s = 墨色档位(1..3), x1, y1, x2, y2, ... }
]]

local Blitbuffer = require("ffi/blitbuffer")
local floor = math.floor
local ceil = math.ceil
local sqrt = math.sqrt
local abs = math.abs

local Render = {}

-- ---------------------------------------------------------------- 灰度混合

--[[--
覆盖率量化到 1/64 档，预生成 Color8A。

不量化就得每个像素现造一个 cdata，LuaJIT 上那是实打实的 GC 压力；量化后热路径
零分配。64 档时相邻两档的灰阶差 4/255，比墨水屏本身的灰阶抖动还小。
]]
local Color8A = Blitbuffer.Color8A
local LEVELS = 63
local blend_cache = setmetatable({}, { __mode = "k" })

local function blendColor(gray, level)
    local by_gray = blend_cache[gray]
    if not by_gray then
        by_gray = {}
        blend_cache[gray] = by_gray
        for l = 0, LEVELS do
            by_gray[l] = Color8A(gray, floor(l * 255 / LEVELS + 0.5))
        end
    end
    return by_gray[level]
end

--[[--
按覆盖率画一个像素。cov ∈ (0, 1]。

调用方必须保证 x/y 没越界（见文件头关于 setPixelBlend 的说明）。
]]
local function putPixel(bb, x, y, cov, color, gray)
    if cov >= 0.996 then
        bb:setPixel(x, y, color)
        return
    end
    bb:setPixelBlend(x, y, blendColor(gray, floor(cov * LEVELS + 0.5)))
end

--[[--
把像素下标包围盒 [x0,x1]×[y0,y1]（含端点）夹进画布。返回 nil 表示整个盒子都
在画布外面。
]]
local function clipBox(x0, y0, x1, y1, bw, bh)
    if x0 < 0 then x0 = 0 end
    if y0 < 0 then y0 = 0 end
    if x1 > bw - 1 then x1 = bw - 1 end
    if y1 > bh - 1 then y1 = bh - 1 end
    if x1 < x0 or y1 < y0 then return nil end
    return floor(x0), floor(y0), floor(x1), floor(y1)
end

-- ---------------------------------------------------------------- 基本图元

--[[--
画一个实心圆，逐像素算精确覆盖率。

覆盖率 = (r + 0.5) - dist：dist 是像素中心到圆心的真实距离，所以边缘是一像素宽的
线性过渡带，不存在台阶。这就是笔尖印子的最小形态：沿线按弧长密集撒下去，
相邻印子严丝合缝地叠成一条笔迹。
]]
local function disc(bb, cx, cy, r, color, gray, bw, bh)
    local lim = r + 0.5
    local x0, y0, x1, y1 = clipBox(floor(cx - lim), floor(cy - lim),
                                   ceil(cx + lim), ceil(cy + lim), bw, bh)
    if not x0 then return end
    local lim2 = lim * lim
    for py = y0, y1 do
        local ey = py + 0.5 - cy
        local ey2 = ey * ey
        for px = x0, x1 do
            local ex = px + 0.5 - cx
            local d2 = ex * ex + ey2
            if d2 < lim2 then
                local cov = lim - sqrt(d2)
                putPixel(bb, px, py, cov > 1 and 1 or cov, color, gray)
            end
        end
    end
end

-- ---------------------------------------------------------------- 胶囊序列

--[[--
把一段锥形胶囊光栅化：中心线 (x0,y0)→(x1,y1)，半径从 r0 线性变到 r1。

逐像素三步：
    t    = 像素在这段中心线垂足位置的参数（夹到 [0,1]，落在两端端点上）
    r    = r0 + (r1-r0)·t            ← 半径沿轴线性插值
    cov  = (r + 0.5) - dist(P, C(t)) ← 覆盖率，>1 直接落实心

这样画出来的笔画没有多边形拼接：它的形状就是「一串半径渐变的圆盘沿线扫过去」
的并集，边缘只有一层由「距离 → 覆盖率」给出的固定宽度过渡带，关节处既不露接缝
也不会叠出黑斑。
]]
local function capsule(bb, x0, y0, r0, x1, y1, r1, color, gray, bw, bh)
    local dx, dy = x1 - x0, y1 - y0
    local len2 = dx * dx + dy * dy
    if len2 < 1e-6 then
        -- 退化成一个圆（抬笔那一小段常常就是同一个点）
        disc(bb, x1, y1, (r0 + r1) * 0.5, color, gray, bw, bh)
        return
    end
    local rmax = r0 > r1 and r0 or r1
    local reach = rmax + 1
    local lx, hx = x0, x1
    if x1 < lx then lx, hx = x1, x0 end
    local ly, hy = y0, y1
    if y1 < ly then ly, hy = y1, y0 end
    local ax, ay, bx, by = clipBox(floor(lx - reach), floor(ly - reach),
                                   ceil(hx + reach), ceil(hy + reach), bw, bh)
    if not ax then return end

    local inv = 1 / len2
    local dr = r1 - r0
    for py = ay, by do
        local ey = py + 0.5 - y0
        local eydy = ey * dy
        for px = ax, bx do
            local ex = px + 0.5 - x0
            local t = (ex * dx + eydy) * inv
            if t < 0 then t = 0 elseif t > 1 then t = 1 end
            local qx = ex - t * dx
            local qy = ey - t * dy
            local lim = r0 + dr * t + 0.5
            local d2 = qx * qx + qy * qy
            if d2 < lim * lim then
                local cov = lim - sqrt(d2)
                putPixel(bb, px, py, cov > 1 and 1 or cov, color, gray)
            end
        end
    end
end

--[[--
胶囊序列：上一层（hw_ink）吐出来的扁平数组
    p = { n = 段数, x0,y0,r0,x1,y1,r1, x0,y0,r0,... }
每段 6 个数字，第 k 段的下标从 k*6-5 开始。

对外只提供 capsuleRange / segBBox / feedStep 这一组：起笔那个圆头由 hw_ink 当成一段
退化胶囊吐出来，所以这里不再单独提供「画圆」接口 —— 多一条入口就多一处
「两种画法画得不一样」的风险。
]]

--[[--
画第 from..to 段（1 起算，含两端）。

这是热路径里唯一的绘图入口：书写时每帧只调 to-from+1 = 一两段，重绘整页时才遍历整条。
]]
function Render.capsuleRange(bb, p, from, to, ox, oy, color, gray)
    if not p or not p.n then return end
    if from < 1 then from = 1 end
    if to > p.n then to = p.n end
    if to < from then return end
    ox = ox or 0
    oy = oy or 0
    local bw, bh = bb:getWidth(), bb:getHeight()
    for k = from, to do
        local j = k * 6 - 5
        capsule(bb, ox + p[j], oy + p[j + 1], p[j + 2],
                    ox + p[j + 3], oy + p[j + 4], p[j + 5],
                color, gray, bw, bh)
    end
end

--- 重放一整条美化后的笔画。
function Render.beautyStroke(bb, p, ox, oy, color, gray)
    if not p or not p.n or p.n < 1 then return end
    Render.capsuleRange(bb, p, 1, p.n, ox, oy, color, gray)
end

--[[--
第 from..to 段的外接矩形（已经把半径算进去），给局部刷新用。

局部刷新的框必须套住整颗胶囊而不是只有中心线，否则笔锋会被切掉一条边。
]]
function Render.segBBox(p, from, to, ox, oy)
    if not p or not p.n or p.n < 1 then return nil end
    if from < 1 then from = 1 end
    if to > p.n then to = p.n end
    if to < from then return nil end
    ox = ox or 0
    oy = oy or 0
    local X0, Y0, X1, Y1
    for k = from, to do
        local j = k * 6 - 5
        local ax, ay, ar = ox + p[j], oy + p[j + 1], p[j + 2]
        local bx, by, br = ox + p[j + 3], oy + p[j + 4], p[j + 5]
        local lx, hx = ax - ar, ax + ar
        if bx - br < lx then lx = bx - br end
        if bx + br > hx then hx = bx + br end
        local ly, hy = ay - ar, ay + ar
        if by - br < ly then ly = by - br end
        if by + br > hy then hy = by + br end
        if X0 == nil then
            X0, Y0, X1, Y1 = lx, ly, hx, hy
        else
            if lx < X0 then X0 = lx end
            if hx > X1 then X1 = hx end
            if ly < Y0 then Y0 = ly end
            if hy > Y1 then Y1 = hy end
        end
    end
    return X0, Y0, X1, Y1
end

--[[--
「喂一个新点 → 把新冒出来的那几段画出来」这件事在两个入口（书内批注 / 手写本）
里各写一遍容易漏掉某一头，收在这里。

返回新增段数；首段的段号是 out.n - 新增数 + 1，调用方要刷新局部就从这个位置
再调一次 segBBox 取框。
]]
function Render.feedStep(bb, ink, st, out, x, y, color, gray)
    local n0 = out.n
    local added = ink:push(st, x, y, out)
    if added > 0 then
        Render.capsuleRange(bb, out, n0 + 1, out.n, 0, 0, color, gray)
    end
    return added
end

-- ---------------------------------------------------------------- 普通（等宽）

--- 在 bb 上画一条宽 w 的线段：沿线段逐步画方块，简单且足够快。
function Render.segment(bb, x0, y0, x1, y1, w, color)
    local dx = x1 - x0
    local dy = y1 - y0
    local adx = abs(dx)
    local ady = abs(dy)
    local steps = adx > ady and adx or ady

    if steps < 1 then
        Render.dot(bb, x0, y0, w, color)
        return
    end

    steps = floor(steps)
    local sx = dx / steps
    local sy = dy / steps
    local x, y = x0, y0
    for _ = 0, steps do
        Render.dot(bb, x, y, w, color)
        x = x + sx
        y = y + sy
    end
end

--- 画一个方的「点」，笔宽就是方块边长。
function Render.dot(bb, x, y, w, color)
    local half = floor(w / 2)
    bb:paintRect(floor(x) - half, floor(y) - half, w, w, color)
end

-- ---------------------------------------------------------------- 统一入口

--[[--
重放整条笔画。ox/oy 用于整体偏移，书写路径里恒为 0。

ink 传 nil 就走等宽老路径（美化关闭时的兜底，也能读老版本存的笔迹）；
传 hw_ink 实例就走变宽 + 抗锯齿。out 是可复用的临时数组。
]]
function Render.stroke(bb, s, ox, oy, color, gray, ink, out)
    ox = ox or 0
    oy = oy or 0
    local n = s.n
    if not n or n < 1 then return end

    if ink then
        Render.beautyStroke(bb, ink:compute(s, out), ox, oy, color, gray)
        return
    end

    if n == 1 then
        Render.dot(bb, ox + s[1], oy + s[2], s.w, color)
        return
    end
    for i = 1, (n - 1) * 2, 2 do
        Render.segment(bb, ox + s[i], oy + s[i + 1],
                       ox + s[i + 2], oy + s[i + 3], s.w, color)
    end
end

--[[--
笔画的外接矩形，用于局部刷新和命中判断；bbox 为 nil 表示空笔画。

美化开启时笔画会比 s.w 更粗（最多 max_scale 倍），这里按需放大，
否则抬笔时局部刷新的框会切掉笔锋的边缘。
]]
function Render.bbox(s, ink)
    if not s or s.n < 1 then return nil end
    local x0, y0, x1, y1 = s[1], s[2], s[1], s[2]
    for i = 3, s.n * 2, 2 do
        local x, y = s[i], s[i + 1]
        if x < x0 then x0 = x end
        if x > x1 then x1 = x end
        if y < y0 then y0 = y end
        if y > y1 then y1 = y end
    end
    local half = floor((s.w or 1) / 2) + 1
    if ink then half = floor(half * ink.max_scale) + 1 end
    return x0 - half, y0 - half, x1 + half, y1 + half
end

return Render
