--[[--
书写刷新调度器。

为什么需要这么个东西
--------------------
在墨水屏上「画进 framebuffer」和「肉眼看见」是两件事：像素写进去只是第一步，
还必须向 EPDC（电子纸显示控制器）发一次更新请求，屏幕才会真的变色。
而不同的波形（waveform）差别大到决定了笔迹能不能看见：

  * KPW5 属于 MTK Kindle。Screen:refreshFast 走到的是 MTK_WAVEFORM_MODE_DU，
    而且驱动还会额外带上 EPDC_FLAG_FORCE_MONOCHROME —— 也就是
    「任意灰度 → 1bit 黑白」（koreader-base ffi/framebuffer_mxcfb.lua 里
    refresh_mtk() 那一段原话）。用来给 reFlow 文本做反显高亮很合适，
    但我们的笔迹恰恰是大量抗锯齿灰阶像素，会被整片压成白色 ——
    这就是「写着看着没有，点一下刷新才出来」的根本原因。

  * Screen:refreshUI 在这台机器上是 WAVEFORM_MODE_AUTO，驱动把
    hist_gray_waveform_mode 设成 MTK_GC16，并且**不**带 FORCE_MONOCHROME，
    16 级灰阶能正常还原。同时 AUTO 不会被提升成 UPDATE_MODE_FULL，
    因此不像 REAGL 那样要连着阻塞两次 wait-for-complete ——
    既不黑闪也不卡，正适合书写热路径。

  * 顺带说明为什么以前「关掉局部快刷」会写一两个字黑屏一下：那条回退路径用的是
    Screen:refreshPartial，在 KPW5 上等于 MTK_WAVEFORM_MODE_GLR16（REAGL）。
    REAGL 会 (1) 先等上一个 marker 完成，再把 update_mode 提升为 FULL，
    (2) 又等本次 marker 完成 —— 两次阻塞，频率一高就表现为黑屏卡顿。

代价与对策
----------
每次 ioctl 都有固定开销，逐点发刷新会把弱 CPU 拖垮。所以这里做三件事：

  1) 合并 —— 把两次真实刷新之间的所有小段并成一个外接矩形，一次刷完；
  2) 节流 —— 两次 EPDC 更新之间留一个最短间隔；
  3) 兜底 —— 写字停顿（手指没抬、不再有点进来）时，由 UIManager 定时器
     补一次刷新；落笔和抬笔则强制立刻刷，保证「第一下」和「最后一笔」一定有反馈。

需要注意的是：**像素始终是按原始触点实时画进 framebuffer 的**，被节流的只是
「把这块区域送到屏幕」这一步。所以节流不会丢笔，只是最多延迟一个间隔显示。
--]]

local Device = require("device")
local Screen = Device.screen

local ok_time, T = pcall(require, "ui/time")

local function realNowMs()
    if ok_time and T.now and T.to_ms then
        return T.to_ms(T.now())
    end
    -- 理论上走不到这里，ui/time 一定存在；留个兜底免得整个插件起不来
    return math.floor((os.clock() or 0) * 1000)
end

local Refresh = {}

--[[--
画质档位。

interval 两次 EPDC 刷新的最短间隔（毫秒）。0 表示每个点都刷。

kind 决定用哪一类波形；每台机器实际能用的函数不一样，会按 Fallback 顺序探测：
    fast  = DU     —— 只有黑白两色，抗锯齿/淡墨会被压白
    gray  = UI/AUTO—— 灰阶，不闪不阻塞，书写的默认选择
    reagl = REAGL  —— 16 灰阶且自带残影清理，但两次阻塞，慢
]]
Refresh.MODES = {
    {
        key = "gray",
        text = "标准（推荐：灰阶可见，跟手）",
        interval = 45,
        kind = "gray",
        help_text = "书写时用 UI/AUTO 波形：能显示抗锯齿灰阶，写的过程中笔迹立刻可见，"
            .. "又不像 REAGL 那样阻塞。KPW5 上这是默认项。",
    },
    {
        key = "clean",
        text = "抗残影（最干净，略慢）",
        interval = 200,
        kind = "reagl",
        help_text = "书写时用 REAGL 波形：残影最少、字迹最实，但每次更新要等待控制器完成，"
            .. "写快了会明显跟不上手。适合慢慢写、或特别在意残影的场景。",
    },
    {
        key = "fast",
        text = "极速（黑白两色，淡墨可能看不见）",
        interval = 0,
        kind = "fast",
        help_text = "DU 波形，延迟最低、最省资源，但只能显示纯黑与纯白：细笔画的抗锯齿灰边、"
            .. "灰色墨水有可能会直到下次整屏刷新才显出来。只在上面的档位都嫌慢时才用。",
    },
}

Refresh.MODES_BY_KEY = {}
for i = 1, #Refresh.MODES do
    Refresh.MODES_BY_KEY[Refresh.MODES[i].key] = Refresh.MODES[i]
end
Refresh.DEFAULT_MODE = "gray"

-- 每档尝试的 Screen 方法顺序。注意 gray 的回退里刻意排除了 refreshFast：
-- DU 会把灰阶压白，用它兜底等于把要修的问题又请回来。
local FALLBACK = {
    gray  = { "refreshUI", "refreshPartial", "refreshFull" },
    reagl = { "refreshPartial", "refreshUI", "refreshFull" },
    fast  = { "refreshFast", "refreshPartial", "refreshFull" },
}

-- 选一个真正存在的 Screen 刷新方法。
function Refresh.waveFn(kind)
    local names = FALLBACK[kind] or FALLBACK.gray
    for i = 1, #names do
        local fn = Screen[names[i]]
        if type(fn) == "function" then
            local method = fn
            return function(x, y, w, h) return method(Screen, x, y, w, h) end
        end
    end
    return nil
end

--- 当前设备推荐/实际采用的波形名，用于诊断显示。
function Refresh.waveName(kind)
    local names = FALLBACK[kind] or FALLBACK.gray
    for i = 1, #names do
        if type(Screen[names[i]]) == "function" then return names[i] end
    end
    return "无（设备不支持局部刷新）"
end

--- 把任意两个角点夹到屏幕范围内。返回 nil 表示完全在屏幕外。
function Refresh.clip(x0, y0, x1, y1)
    local sw, sh = Screen:getWidth(), Screen:getHeight()
    local x = math.floor(math.min(x0, x1))
    local y = math.floor(math.min(y0, y1))
    local xe = math.ceil(math.max(x0, x1))
    local ye = math.ceil(math.max(y0, y1))
    if x < 0 then x = 0 end
    if y < 0 then y = 0 end
    if xe > sw then xe = sw end
    if ye > sh then ye = sh end
    if xe <= x or ye <= y then return nil end
    return x, y, xe - x, ye - y
end

--[[--
全局唯一的 UIManager 句柄，按需取。

用 pcall + package.loaded 兜了一层：万一这个模块被先 require 而 UIManager 还没起来，
也不至于让插件加载时就崩掉（缺了它只是没有「停顿补刷」，核心功能不受影响）。
]]
local UIManager

-- ---------------------------------------------------------------- 调度器

local Governor = {}
Governor.__index = Governor

local function getUIManager()
    if UIManager ~= nil then return UIManager or nil end
    local mod
    local ok = pcall(function()
        mod = package.loaded["ui/uimanager"]
        if not (mod and mod.scheduleIn) then mod = require("ui/uimanager") end
    end)
    UIManager = (ok and type(mod) == "table" and mod.scheduleIn and mod) or false
    return UIManager or nil
end

--[[--
新建一个调度器。

o.mode_key  画质档位 key（见 Refresh.MODES）
o.sync      可选，刷新前的回调 sync(x,y,w,h)。
            离屏画布的用法在主笔迹写在自己的 bb 上，刷新前必须先把这块区域抄进
            framebuffer，否则刷出去的还是旧内容。
o.now_ms    可选，注入时钟（离线测试用）
]]
function Governor:new(o)
    o = o or {}
    setmetatable(o, self)
    o.box = nil          -- {x0, y0, x1, y1}，含 pad 的累积外接矩形
    o.last_ms = nil      -- 上次真正发起 EPDC 刷新的时刻
    o.armed = false      -- 是否已挂 UIManager 兜底任务
    o.alive = true
    o._fn = {}
    o:setMode(o.mode_key or Refresh.DEFAULT_MODE)
    return o
end

function Governor:clock()
    if self.now_ms then return self.now_ms() end
    return realNowMs()
end

--- 切换画质档位。返回一个 bool：这台设备到底有没有可用的波形函数。
function Governor:setMode(key)
    local m = Refresh.MODES_BY_KEY[key]
    if not m then key, m = Refresh.DEFAULT_MODE, Refresh.MODES_BY_KEY[Refresh.DEFAULT_MODE] end
    self.mode_key = key
    self.kind = m.kind
    self.interval = m.interval
    return self:fn() ~= nil
end

function Governor:fn(kind)
    kind = kind or self.kind
    local fn = self._fn[kind]
    if fn == nil then
        fn = Refresh.waveFn(kind) or false
        self._fn[kind] = fn
    end
    return fn or nil
end

--[[--
抬笔收尾时应该用的波形。

极速档（DU）会把抗锯齿灰阶压成白色，写出来的细笔画可能整栏看不见。
抬笔之后对延迟已经不敏感了（手指已经离开屏幕），所以用灰阶波形补一次，
保证「写完这一笔一定看得见」。其余档位返回 nil —— 沿用当前档位即可。
]]
function Governor:finishKind()
    if self.kind == "fast" then return "gray" end
    return nil
end

--- 把攒着的显示请求一次性刷出去，抬笔/收工时用。
function Governor:finish()
    return self:flush(self:finishKind())
end

function Governor:reset()
    self.box = nil
    self.last_ms = nil
end

--- 累加一块脏矩形。坐标可以是任意两个对角点。
function Governor:add(x0, y0, x1, y1, pad)
    local p = pad or 2
    local xa = math.min(x0, x1) - p
    local ya = math.min(y0, y1) - p
    local xb = math.max(x0, x1) + p
    local yb = math.max(y0, y1) + p
    local b = self.box
    if not b then
        self.box = { xa, ya, xb, yb }
        return
    end
    if xa < b[1] then b[1] = xa end
    if ya < b[2] then b[2] = ya end
    if xb > b[3] then b[3] = xb end
    if yb > b[4] then b[4] = yb end
end

--- 已经到了该真刷的时间吗。
function Governor:due()
    if not self.box then return false end
    if self.interval <= 0 then return true end
    if not self.last_ms then return true end
    return (self:clock() - self.last_ms) >= self.interval
end

--- 真的把这一小块送上屏幕。返回是否发出过更新。
function Governor:flush(kind)
    local b = self.box
    self.box = nil
    if not b then return false end
    local x, y, w, h = Refresh.clip(b[1], b[2], b[3], b[4])
    if not x then return false end
    self.last_ms = self:clock()
    -- 离屏画布：先把这块区域抄进屏幕 framebuffer，否则刷出去的还是旧内容
    if self.sync then self.sync(x, y, w, h) end
    local fn = self:fn(kind)
    if not fn then return false end
    fn(x, y, w, h)
    self.flushed = (self.flushed or 0) + 1
    self.last_area = w * h
    return true
end

--- 挂一个 UIManager 定时器，保证「写完干脆停住不动」时最后那截也会显出来。
function Governor:arm()
    if self.armed or not self.box then return end
    local wait = self.interval
    if wait > 0 and self.last_ms then
        wait = wait - (self:clock() - self.last_ms)
        if wait < 0 then wait = 0 end
    end
    local UM = getUIManager()
    if not UM then return end          -- 没有定时器就退化：等下一个触点时一起刷
    self.armed = true
    local governor = self
    governor._task = function()
        governor.armed = false
        if governor.alive then governor:flush() end
    end
    UM:scheduleIn(wait / 1000, governor._task)
end

--[[--
画了一小段之后调用：记下脏矩形，并在合适的时机把它刷出去。

force=true 表示立刻刷（落笔、抬笔、橡皮这种「必须马上看到」的时刻）。
]]
function Governor:touch(x0, y0, x1, y1, pad, force)
    self:add(x0, y0, x1, y1, pad)
    if force then
        -- 落笔 / 抬笔：这一下必须看得见。极速档也会临时改用灰阶波形，
        -- 因为 DU 会把起笔的圆头和收笔的细尾巴整块压白。
        self:flush(self:finishKind())
    elseif self:due() then
        self:flush()
    else
        self:arm()
    end
end

--- 结束书写 / 关闭部件时调用：把剩下的刷完，并让兜底任务失效。
function Governor:close()
    self:flush()
    self.alive = false
end

--- 重新进入书写时调用：再次允许停顿补刷。
function Governor:open()
    self.alive = true
end

Refresh.SETTING_KEY = "handwrite_refresh_mode"

local function gsettings()
    return type(_G) == "table" and _G.G_reader_settings or nil
end

--- 读出保存的画质档位；顺手把老版本的「局部快刷」布尔开关迁移过来。
function Refresh.loadModeKey()
    local G = gsettings()
    local key
    if G and G.readSetting then
        key = G:readSetting(Refresh.SETTING_KEY)
        if key == nil and G:readSetting("handwrite_fast_refresh") == false then
            -- 旧版「关掉局部快刷」意味着想要更干净的画面，等价于现在的「抗残影」
            key = "clean"
        end
    end
    if not Refresh.MODES_BY_KEY[key] then key = Refresh.DEFAULT_MODE end
    return key
end

function Refresh.saveModeKey(key)
    local G = gsettings()
    if G and G.saveSetting then G:saveSetting(Refresh.SETTING_KEY, key) end
end

Refresh.Governor = Governor

-- Lua 5.1 的 require 只回传第一个返回值，所以两个东西都挂在 Refresh 上。
return Refresh
