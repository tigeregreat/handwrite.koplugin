--[[--
笔迹美化算法（纯计算，不碰 blitbuffer，方便离线单测）。

管线照着 GoodNotes / Notability 这类笔记软件公开的通用做法搭，再按 Kindle 的
算力和手感要求裁剪：

    原始触点 → 指数平滑去抖 → 二次 B 样条（折线变 C1 连续的曲线）
             → 沿曲线按弧长细分 → 每个点用速度算出半径 → 输出一串锥形胶囊

「怎么发射 höher,」三个关键取舍：

1. **用二次 B 样条**，而不是直接连折线。取相邻控制点的中点做端点、控制点本身做
   贝塞尔控制点，得到的是 C1 连续的曲线 —— 这才是「顺滑」的来源。常见的
   Catmull-Rom 要往后多看两个点，在墨水屏上滞后感太重；这套只要多看一个点。
2. **半径只依赖过去**（因果），所以书写时能立刻把最新一段增量画出来，抬笔不必
   重画整条笔画；换页重绘走同一份代码，结果逐点一致，不会跳变。
3. **半径不落盘**。sidecar 里还是原来的 {n, w, s, x, y...}，重绘时重算一遍即可，
   老笔迹照样能美化。

输出是一串「锥形胶囊」（两端半径可以不同的线段），白话一点就是一串依次相接的
小圆台；渲染端按到中心线的距离算覆盖率，因此不需要像多边形填充那样拼接，
也不会有锯齿和接缝。
]]

local sqrt = math.sqrt
local ceil = math.ceil

local Ink = {
    -- 笔锋强度（由 applyPreset 覆盖）
    thinning     = 0.50,   -- 速度对笔宽的影响：0 = 等宽，越大笔锋越明显
    streamline   = 0.25,   -- 输入去抖：0 = 不过滤，越大越顺但越滞后

    speed_ref    = 18,     -- 相邻点距离达到这个值就算「最快」
    press_smooth = 0.45,   -- 压感低通，避免笔宽忽粗忽细
    press_start  = 0.72,   -- 落笔时的初始压感（手指刚落下时一般都慢）

    taper_in     = 6,      -- 起笔渐入长度（px）
    start_scale  = 0.72,   -- 落笔那一瞬的细度
    head_scale   = 1.22,   -- 起笔顿笔的峰值

    --[[
    「写着写着线就没了」有两个原因，都要堵住：

    1. 相对下限 min_scale：手划得快的时候宽度只剩百分之几十。这个值不能设太大，
       否则三档笔锋在快速段的半径全被夹到同一个值，「弱/中/强」看起来就没区别了；
    2. 绝对下限 min_radius：细笔（笔宽 2px）时就算按满比例也只剩不到 1px，
       抗锯齿一摊就变淡灰。0.9 保证笔画正中一定有一颗纯黑像素，外面才是一圈灰边，
       这一条才是真正兜住「线消失」的。
    ]]
    min_scale    = 0.45,
    max_scale    = 1.35,
    min_radius   = 0.9,    -- 绝对下限（px），覆盖 min_scale

    -- 段长既控制椒盐同时也控制性能：太短则每段的计算量白花（相邻胶囊大量重叠），
    -- 太长则捏合误差变大。按「半径的比例 + 绝对下限」两者取大值最稳。
    seg_min      = 1.6,    -- 每段最短长度（px）
    seg_ratio    = 0.8,    -- 段长还不得小于「半径 × 这个值」
    max_subdiv   = 24,     -- 单段样条最多切成几小段
}

--- 三档笔锋强度，菜单里直接照这个表生成。
--[[
streamline 数字刻意调小了：它对去抖很有用，但它的群延迟约等于 (1-α)/α 个采样点，
0.25 就是整整 3 个点（10px 左右）—— 手指写字会明显觉得「笔尖跟不上」。
0.20 大约 2 个点的延迟，配合二次 B 样条本身的平滑已经够了。
]]
Ink.PRESETS = {
    { text = "弱（工整）",   thinning = 0.32, streamline = 0.14 },
    { text = "中（推荐）",   thinning = 0.50, streamline = 0.20 },
    { text = "强（毛笔感）", thinning = 0.72, streamline = 0.28 },
}
Ink.DEFAULT_PRESET = 2

function Ink:applyPreset(i)
    local p = self.PRESETS[i] or self.PRESETS[self.DEFAULT_PRESET]
    self.thinning = p.thinning
    self.streamline = p.streamline
    self.preset = i
end

--[[--
压感 + 起笔渐入 → 半径系数（乘在「笔宽的一半」上）。

起笔曲线用 s(t) = 渐入 + 抛物线凸起，t∈[0,1]：
    s = start + (1-start)*t + (head-1)*4t(1-t)
t=0 起笔细，t=0.5 顿笔峰，t=1 正好回到 1 —— 保证和渐入段结束后的正常段接得上，
不会在 taper_in 那里突然掉一档粗细。
]]
function Ink:scaleOf(press, run)
    local k = press + (1 - press) * (1 - self.thinning)
    if run < self.taper_in then
        local t = run / self.taper_in
        local bump = 4 * t * (1 - t)
        k = k * (self.start_scale + (1 - self.start_scale) * t
                 + (self.head_scale - 1) * bump)
    end
    if k < self.min_scale then return self.min_scale end
    if k > self.max_scale then return self.max_scale end
    return k
end

--- 压感 + 起笔渐入 + 绝对下限 → 半径（px）。书写增量和整条重算都走这里，
--- 保证同一条笔画无论算多少遍结果都一样。
function Ink:radiusOf(base, press, run)
    local r = base * self:scaleOf(press, run)
    if r < self.min_radius then return self.min_radius end
    return r
end

-- ------------------------------------------------------------ 控制点

--- 把一段二次贝塞尔按弧长切成若干段，追加到 out。
local function subdivide(out, ax, ay, ar, cx, cy, cr, bx, by, br, steps)
    local n = out.n
    local px, py, pr = ax, ay, ar
    for i = 1, steps do
        local t = i / steps
        local u = 1 - t
        local w0, w1, w2 = u * u, 2 * u * t, t * t
        local x = w0 * ax + w1 * cx + w2 * bx
        local y = w0 * ay + w1 * cy + w2 * by
        local r = w0 * ar + w1 * cr + w2 * br
        local j = n * 6
        out[j + 1] = px
        out[j + 2] = py
        out[j + 3] = pr
        out[j + 4] = x
        out[j + 5] = y
        out[j + 6] = r
        n = n + 1
        px, py, pr = x, y, r
    end
    out.n = n
end

--[[--
st.p 里按 {x1,y1,r1, x2,y2,r2, ...} 存「控制点」，st.n 是个数。

每来一个新控制点就确定一段二次贝塞尔：
    起点   = mid(前前一个控制点, 前一个控制点)   （头一段就是第一个点本身）
    控制点 = 前一个控制点
    终点   = mid(前一个控制点, 新控制点)
抬笔时再补收尾一段（终点就是最后一个控制点本身）。相邻段共用端点、切线也连续，
连起来自然是一条光滑曲线。
]]

--[[--
newState 会顺手往 out 里吐一个退化的胶囊（起点终点重合，就是一个圆）。

这一步很关键：落笔那一瞬间手指还没移动，屏幕上必须先出现一个点；而这个点如果由
调用方自己另画一个，compute（重绘）时是不会重画它的 —— 两种画法就会差几个像素，
抬手的瞬间笔迹会「闪」。让它成为输出流里的第 1 段，两种路径就彻底一致了。
]]
function Ink:newState(x, y, base, out)
    local r = self:radiusOf(base, self.press_start, 0)
    local p = { x, y, r }
    local st = {
        p = p, n = 1,
        x = x, y = y,                 -- 上一个「平滑后」的点
        run = 0, press = self.press_start, base = base,
    }
    st.lr = r
    if out then
        out.n = 0
        subdivide(out, x, y, r, x, y, r, x, y, r, 1)
    end
    return st
end

--- 输出「刚刚确定的那一段」，返回新增了几段。
function Ink:_emit(st, out)
    local n = st.n
    if n < 2 then return 0 end
    local p = st.p
    local ci, ni = n * 3 - 5, n * 3 - 2      -- P[n-1] 与 P[n] 的起始下标
    local cx, cy, cr = p[ci], p[ci + 1], p[ci + 2]
    local ax, ay, ar
    if n == 2 then
        ax, ay, ar = p[1], p[2], p[3]
    else
        local i0 = n * 3 - 8                 -- P[n-2]
        ax = (p[i0] + p[ci]) * 0.5
        ay = (p[i0 + 1] + p[ci + 1]) * 0.5
        ar = (p[i0 + 2] + p[ci + 2]) * 0.5
    end
    local bx = (p[ci] + p[ni]) * 0.5
    local by = (p[ci + 1] + p[ni + 1]) * 0.5
    local br = (p[ci + 2] + p[ni + 2]) * 0.5

    -- 用两段弦长估计弧长，够用来决定切几刀
    local e1x, e1y = cx - ax, cy - ay
    local e2x, e2y = bx - cx, by - cy
    local est = sqrt(e1x * e1x + e1y * e1y) + sqrt(e2x * e2x + e2y * e2y)
    local want = cr * self.seg_ratio
    if want < self.seg_min then want = self.seg_min end
    local steps = ceil(est / want)
    if steps < 1 then steps = 1 elseif steps > self.max_subdiv then steps = self.max_subdiv end

    local before = out.n
    subdivide(out, ax, ay, ar, cx, cy, cr, bx, by, br, steps)
    return out.n - before
end

--[[--
灌进一个新点，把 newly determined 的段写进 out。

返回新增的段数；out.n 之前的内容保留，方便调用方同一张表反复复用。
]]
function Ink:push(st, x, y, out)
    local keep = 1 - self.streamline
    local fx = st.x + (x - st.x) * keep
    local fy = st.y + (y - st.y) * keep

    local n = st.n
    if n == 0 then
        st.x, st.y = fx, fy
        st.p[1], st.p[2] = fx, fy
        st.p[3] = self:radiusOf(st.base, st.press, 0)
        st.n = 1
        return 0
    end

    local dx, dy = fx - st.x, fy - st.y
    local d = sqrt(dx * dx + dy * dy)
    if d < 1e-6 then return 0 end
    st.x, st.y = fx, fy

    st.run = st.run + d
    -- 速度 → 压感：走得快的地方细，停下来的地方粗
    local sp = 1 - d / self.speed_ref
    if sp < 0 then sp = 0 elseif sp > 1 then sp = 1 end
    st.press = st.press + (sp - st.press) * self.press_smooth

    st.n = n + 1
    local j = n * 3
    st.p[j + 1], st.p[j + 2], st.p[j + 3] = fx, fy,
        self:radiusOf(st.base, st.press, st.run)

    return self:_emit(st, out)
end

--- 抬笔：补上收尾那一段。只点了一下时会输出一个退化的胶囊（就是个点）。
function Ink:finish(st, out)
    local n = st.n
    if n < 1 then return 0 end
    local p = st.p
    local i = n * 3 - 2
    local cx, cy, cr = p[i], p[i + 1], p[i + 2]
    local ax, ay, ar = cx, cy, cr
    if n >= 2 then
        local ci = n * 3 - 5
        ax = (p[ci] + p[i]) * 0.5
        ay = (p[ci + 1] + p[i + 1]) * 0.5
        ar = (p[ci + 2] + p[i + 2]) * 0.5
    end
    local est = sqrt((cx - ax) * (cx - ax) + (cy - ay) * (cy - ay))
    local want = cr * self.seg_ratio
    if want < self.seg_min then want = self.seg_min end
    local steps = ceil(est / want)
    if steps < 1 then steps = 1 elseif steps > self.max_subdiv then steps = self.max_subdiv end

    local before = out.n
    subdivide(out, ax, ay, ar, cx, cy, cr, cx, cy, cr, steps)
    return out.n - before
end

-- ------------------------------------------------------------ 整条重算（重绘）

--[[--
把整条笔画重算成扁平段数组 { n, x0,y0,r0,x1,y1,r1, ... }（每段 6 个数字）。

走的完全是 push/finish 那条路，所以「边写边画」和「换页重绘」逐点相同；
out 可以复用（传同一个表进来即可），重绘一页不会每条笔画都分配新表。
]]
function Ink:compute(s, out)
    out = out or {}
    out.n = 0
    local n = s and s.n or 0
    if n < 1 then return out end

    local st = self:newState(s[1], s[2], (s.w or 4) * 0.5, out)
    for i = 2, n do
        self:push(st, s[2 * i - 1], s[2 * i], out)
    end
    self:finish(st, out)
    return out
end

return Ink
