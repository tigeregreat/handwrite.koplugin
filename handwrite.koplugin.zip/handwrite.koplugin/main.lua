--[[--
手写笔记（handwrite.koplugin）

在阅读中的书页上用手指直接写，笔迹随书保存在 sidecar 里，重开自动恢复；
另外提供一块空白手写本，可存成 PNG。为 Kindle Paperwhite 5（无手写笔、
1236x1648 墨水屏）调优：手指书写、灰阶波形局部刷新、停手后整屏清残影。

墨水屏上「画进显存」和「肉眼看见」是两件事。这块 KP5 之前的书写热路径用的是 DU 波形
（驱动还会带 FORCE_MONOCHROME，把任意灰度压成 1bit 黑白），细致的抗锯齿笔迹会被整片
压白，于是「要手动点一次刷新才看得见」。现在交给 hw_refresh 的调度器：用 UI/AUTO 波形
（16 级灰阶、不阻塞），把相邻小段并成矩形后按间隔节流，并在停手时补刷 ——
详见那个文件的头部注释。

触摸输入：KOReader 没有公开的原始触点 API，这里沿用社区通行做法 —— 包一层
GestureDetector:feedEvent 拿到 slot 坐标（见 capture.lua）。只在书写模式下
安装，退出时卸载，正常阅读不受影响。
]]

local Blitbuffer = require("ffi/blitbuffer")
local ConfirmBox = require("ui/widget/confirmbox")
local DataStorage = require("datastorage")
local Device = require("device")
local Dispatcher = require("dispatcher")
local Event = require("ui/event")
local Notification = require("ui/widget/notification")
local UIManager = require("ui/uimanager")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local ffiutil = require("ffi/util")
local logger = require("logger")
local util = require("util")
local _ = require("gettext")

local Capture = require("hw_capture")
local Ink = require("hw_ink")
local Notebook = require("hw_notebook")
local Render = require("hw_render")
local Store = require("hw_store")
local Toolbar = require("hw_toolbar")
local Refresh = require("hw_refresh")
local Governor = Refresh.Governor

local Screen = Device.screen

-- 版本号以 _meta.lua 为唯一真相源；诊断信息里显示它。
-- require 在个别加载顺序下可能拿不到，退回硬编码，不至于让诊断页报错。
local VERSION = (function()
    local ok, meta = pcall(require, "_meta")
    if ok and type(meta) == "table" and type(meta.version) == "string" then
        return meta.version
    end
    return "1.7.0"
end)()

local PEN_WIDTHS = { 2, 4, 7 }
local ERASER_RADIUS = 18
local SETTING_KEY = "handwrite_ink"
local SAVE_DIR = DataStorage:getFullDataDir() .. "/notes/handwrite"
local MIN_MOVE_SQ = 4            -- 位移小于 2px 不记点，过滤手抖
local FLUSH_EVERY = 8            -- 写几笔落一次盘
local TOUCH_SLOP = 12            -- 命中判定的余量（scaleBySize 之前），手指比点精确不了那么多
local TWO_FINGER_TAP_SQ = 400    -- 双指 tap 判定：单指位移平方小于 20px² 才算「点」而非「捏」
local DEFAULT_FLOAT_DELAY = 10   -- 虚浮窗默认 10 秒后自动收起；0 = 永不隐藏
local FLOAT_DELAYS = { 5, 10, 20, 30, 60 }

-- 墨色档位：仅在灰度屏（4/8bpp）上才有意义，彩屏一律用纯黑
local INK_SHADES = (function()
    local white, black = Blitbuffer.COLOR_WHITE, Blitbuffer.COLOR_BLACK
    if type(white) ~= "number" or white > 0xFF then
        return { black, black, black }
    end
    local function shade(ratio)
        return black + math.floor((white - black) * ratio + 0.5)
    end
    return { shade(0), shade(0.35), shade(0.65) }
end)()

local dispatcher_registered = false

local Handwrite = WidgetContainer:extend{
    name = "handwrite",
    is_doc_only = false,
}

-- ---------------------------------------------------------------- 初始化

function Handwrite:init()
    self.is_reader = self.ui.document ~= nil
    self.drawing = false
    self.eraser = false
    self.bar = nil

    self.pen_width_index = G_reader_settings:readSetting("handwrite_pen_width") or 2
    self.ink_shade = G_reader_settings:readSetting("handwrite_ink_shade") or 1
    self.bar_side = G_reader_settings:readSetting("handwrite_bar_side") or "right"
    self.bar_position = G_reader_settings:readSetting("handwrite_bar_position")
    -- 虚浮窗：工具栏收成右下角一枚半透明小胶囊，点一下再展开
    self.bar_float = G_reader_settings:readSetting("handwrite_bar_float") == true
    self.bar_float_delay = tonumber(G_reader_settings:readSetting("handwrite_bar_float_delay"))
                           or DEFAULT_FLOAT_DELAY   -- 秒；0 = 永不隐藏
    self.float_task = nil
    -- 悬浮窗缩放系数（默认 0.6，即缩小到原来的 60%）
    self.bar_scale = tonumber(G_reader_settings:readSetting("handwrite_bar_scale")) or 0.6
    -- 右下角「刷新」胶囊：是否显示、点击是否立即刷新
    self.refresh_pill_enabled = G_reader_settings:readSetting("handwrite_refresh_pill") ~= false
    self.refresh_tap_refreshes = G_reader_settings:readSetting("handwrite_refresh_tap") ~= false
    -- 书写时的刷新画质（波形 + 节奏）。见 hw_refresh.lua 的 MODES。
    self.refresh_mode = Refresh.loadModeKey()
    self.gov = Governor:new{ mode_key = self.refresh_mode }
    -- 整屏刷新时机："page"=只在停止书写/换页时刷（默认）
    --              "off" =完全手动   数字 = 每 N 笔刷一次
    self:setFullMode(G_reader_settings:readSetting("handwrite_full_mode") or "page")
    -- 字迹美化（笔锋 + 圆笔尖 + 抗锯齿）。关掉退回等宽，是最省 CPU 的兜底。
    self.beautify = G_reader_settings:readSetting("handwrite_beautify") ~= false
    self.beauty_level = G_reader_settings:readSetting("handwrite_beautify_level")
                        or Ink.DEFAULT_PRESET
    self.ink_out = {}       -- 重绘时复用的临时数组，避免每条笔画分配

    self.contacts = {}
    self.n_contacts = 0
    self.passthrough = false
    self.draw_slot = nil
    self.stroke = nil
    -- 小胶囊点击跟踪：从胶囊上按下、又原地抬起的那一根手指
    self.pill_tap_slot = nil
    self.pill_tap_moved = false
    -- 双指 tap 跟踪：两指同时按下、又几乎同时原地抬起 → 翻下一页（不书写）
    self.two_finger = false          -- 当前是否处于双指接触状态
    self.two_finger_down = nil       -- 双指按下瞬间的两指屏幕坐标 {x1,y1,x2,y2}
    self.two_finger_moved = false    -- 双指期间是否有明显位移（有 = 捏合缩放，不翻页）
    self.strokes_since_flush = 0
    self.strokes_since_full = 0

    -- 能否接管触摸（没触屏 / 没有 gesture_detector 的平台上禁用书写）
    self.can_capture = not not (Device.input and Device.input.gesture_detector
                                and Device.input.gesture_detector.feedEvent)

    if self.is_reader then
        local saved = self.ui.doc_settings:readSetting(SETTING_KEY) or {}
        self.store = Store.new(saved.pages)
        self.saved_layout = saved.layout
        self.view:registerViewModule("handwrite", self)
    else
        self.store = Store.new()
    end

    self:registerDispatcher()
    self.ui.menu:registerToMainMenu(self)

    if self.is_reader and self.saved_layout and self.saved_layout ~= self:layoutKey() then
        -- 换个设备/改了分辨率后，旧的屏幕坐标就对不上了，先说一声
        UIManager:nextTick(function()
            UIManager:show(Notification:new{
                text = "手写：页面布局变了（原 " .. self.saved_layout
                    .. "），旧笔迹可能错位",
                timeout = 6,
            })
        end)
    end
end

function Handwrite:layoutKey()
    return string.format("%dx%d", Screen:getWidth(), Screen:getHeight())
end

function Handwrite:registerDispatcher()
    if dispatcher_registered then return end
    dispatcher_registered = true

    Dispatcher:registerAction("handwrite_toggle", {
        category = "none", event = "HandwriteToggle", reader = true,
        title = _("手写：开始/停止书写"),
    })
    Dispatcher:registerAction("handwrite_eraser", {
        category = "none", event = "HandwriteEraser", reader = true,
        title = _("手写：钢笔/橡皮"),
    })
    Dispatcher:registerAction("handwrite_undo", {
        category = "none", event = "HandwriteUndo", reader = true,
        title = _("手写：撤销一笔"),
    })
    Dispatcher:registerAction("handwrite_toolbar", {
        category = "none", event = "HandwriteToolbar", reader = true,
        title = _("手写：显示/隐藏工具栏"),
    })
    Dispatcher:registerAction("handwrite_notebook", {
        category = "none", event = "HandwriteNotebook", reader = true,
        title = _("手写：打开空白手写本"),
    })
end

-- ---------------------------------------------------------------- 生命周期

function Handwrite:onCloseDocument()
    self:teardown()
end

function Handwrite:onCloseWidget()
    self:teardown()
end

function Handwrite:onSuspend()
    self:setDrawing(false)
end

function Handwrite:onScreenResize()
    self:rebuildBar()
end

function Handwrite:onSetRotationMode()
    self:rebuildBar()
end

function Handwrite:teardown()
    Capture:remove()
    self.drawing = false
    self:cancelFloatTask()
    if self.bar then
        UIManager:close(self.bar)
        self.bar = nil
    end
end

--- 关闭文档 / 退出时把笔迹写进 sidecar。
function Handwrite:onSaveSettings()
    if not self.is_reader then return end
    if self.store:isEmpty() then
        self.ui.doc_settings:delSetting(SETTING_KEY)
    else
        self.ui.doc_settings:saveSetting(SETTING_KEY, {
            layout = self:layoutKey(),
            pages = self.store.pages,
        })
    end
end

function Handwrite:flush()
    pcall(function() self.ui.doc_settings:flush() end)
end

-- ---------------------------------------------------------------- 工具栏

function Handwrite:setBarShown(on)
    on = on and true or false
    G_reader_settings:saveSetting("handwrite_bar_shown", on)

    if on then
        if self.bar then return end
        self.bar = Toolbar:new{
            plugin = self,
            side = self.bar_side,
            position = self.bar_position,
        }
        UIManager:show(self.bar, "ui", self.bar.dimen)
    else
        -- 工具栏是「停止书写」的唯一入口，隐藏它就必须同时停止书写
        self:setDrawing(false)
        self:cancelFloatTask()
        if not self.bar then return end
        local dimen = self.bar:getVisibleDimen()
        UIManager:close(self.bar)
        self.bar = nil
        UIManager:setDirty(self.ui, "ui", dimen)
    end
end

function Handwrite:onHandwriteToolbar()
    self:setBarShown(self.bar == nil)
    return true
end

function Handwrite:rebuildBar()
    if not self.bar then return end
    UIManager:close(self.bar)
    self.bar = nil
    UIManager:nextTick(function() self:setBarShown(true) end)
end

function Handwrite:setBarPosition(x, y)
    if not x or not y then return end
    self.bar_position = { x = x, y = y }
    G_reader_settings:saveSetting("handwrite_bar_position", self.bar_position)
end

-- ---------------------------------------------------------------- 虚浮窗

--- 开关虚浮窗：开 = 工具栏收成右下角那枚半透明小胶囊。
function Handwrite:setBarFloat(on)
    on = on and true or false
    self.bar_float = on
    G_reader_settings:saveSetting("handwrite_bar_float", on)
    if not self.bar then
        self:notify(on and "虚浮窗：开" or "虚浮窗：关", 2)
        return
    end
    if on then
        self:collapseBar()
        self:notify("虚浮窗：开\n点右下角小图标唤出工具栏", 3)
    else
        self.bar:setCollapsed(false)
        self:cancelFloatTask()
        self:notify("虚浮窗：关", 2)
    end
end

--- 自动收起的等待时间（秒）；0 = 永不隐藏。
function Handwrite:setBarFloatDelay(sec)
    sec = tonumber(sec) or 0
    if sec < 0 then sec = 0 end
    self.bar_float_delay = sec
    G_reader_settings:saveSetting("handwrite_bar_float_delay", sec)
    self:pokeFloatBar()
    self:notify(sec > 0 and ("浮窗 " .. sec .. " 秒后自动收起") or "浮窗永不自动隐藏", 2)
end

--- 悬浮窗缩放系数（0.4 ~ 1.3）。改完重建工具栏立即生效。
function Handwrite:setBarScale(scale)
    scale = tonumber(scale) or 0.6
    if scale < 0.3 then scale = 0.3 end
    if scale > 1.5 then scale = 1.5 end
    self.bar_scale = scale
    G_reader_settings:saveSetting("handwrite_bar_scale", scale)
    self:rebuildBar()
    self:notify(string.format("悬浮窗大小：%d%%", math.floor(scale * 100 + 0.5)), 2)
end

--- 右下角「刷新」胶囊开关。
function Handwrite:setRefreshPill(on)
    on = on and true or false
    self.refresh_pill_enabled = on
    G_reader_settings:saveSetting("handwrite_refresh_pill", on)
    if self.bar then
        self.bar.refresh_pill_enabled = on
        UIManager:setDirty(self.bar, "ui", self.bar.refresh_pill_dimen)
    end
    self:notify(on and "刷新胶囊：显示" or "刷新胶囊：隐藏", 2)
end

--- 点刷新胶囊是否立即刷新。
function Handwrite:setRefreshTap(on)
    on = on and true or false
    self.refresh_tap_refreshes = on
    G_reader_settings:saveSetting("handwrite_refresh_tap", on)
    self:notify(on and "点刷新胶囊即整屏刷新" or "点刷新胶囊不刷新", 2)
end

--- 点小胶囊 → 唤出完整工具栏，并重新开始倒计时。
function Handwrite:expandBar()
    if not self.bar then return end
    self.bar:setCollapsed(false)
    self:pokeFloatBar()
end

--- 把工具栏收成小胶囊。
function Handwrite:collapseBar()
    self:cancelFloatTask()
    if self.bar and not self.bar.collapsed then self.bar:setCollapsed(true) end
end

function Handwrite:cancelFloatTask()
    if self.float_task then
        UIManager:unschedule(self.float_task)
        self.float_task = nil
    end
end

--[[--
每次和工具栏交互都把「自动收起」的倒计时重新拨一遍。

只有「开了虚浮窗 + 工具栏这会儿是展开的 + 时间不是永不隐藏」三个条件都满足
才真的排一个定时任务；其余情况一律先把旧的撤掉，免得定时器越攒越多。
]]
function Handwrite:pokeFloatBar()
    self:cancelFloatTask()
    if not self.bar_float then return end
    if not self.bar or self.bar.collapsed then return end
    local delay = tonumber(self.bar_float_delay) or 0
    if delay <= 0 then return end
    self.float_task = function() self:collapseBar() end
    UIManager:scheduleIn(delay, self.float_task)
end

function Handwrite:inBar(x, y)
    if not self.bar then return false end
    -- 刷新胶囊始终可点，书写时也要被识别为「交还系统」，别当成落笔起点。
    if self.bar:containsRefresh(x, y, Screen:scaleBySize(TOUCH_SLOP)) then
        return true
    end
    -- 折叠后的小胶囊只有指甲盖大，命中判定给它一圈余量；
    -- 展开态的按钮本来就大，多给余量只会白白吃掉书写面积。
    if self.bar.collapsed then
        return self.bar:contains(x, y, Screen:scaleBySize(TOUCH_SLOP))
    end
    return self.bar:contains(x, y)
end

--- 阅读器上方是否压着一个菜单或对话框。
-- 书写模式会把单指触摸在到达 UIManager 之前就吃掉，而关闭菜单唯一的办法是
-- 点它外面，所以只要有对话框在，书写就让路。
function Handwrite:dialogOnTop()
    local below = self.bar and self.bar:windowBelow()
    return below ~= nil and below ~= self.ui
end

-- ---------------------------------------------------------------- 绘制状态

function Handwrite:notify(text, timeout)
    UIManager:show(Notification:new{ text = text, timeout = timeout })
end

function Handwrite:currentPage()
    if self.view and self.view.state and self.view.state.page then
        return self.view.state.page
    end
    return 1
end

function Handwrite:inkColor(shade)
    return INK_SHADES[shade or 1] or Blitbuffer.COLOR_BLACK
end

--- 抗锯齿混合用的灰度值（0 = 纯黑），要和 inkColor 对应上。
function Handwrite:inkGray(shade)
    local c = INK_SHADES[shade or 1]
    if type(c) == "number" then return c end
    return 0
end

--[[--
返回绘制用的美化引擎，关闭时返回 nil（走等宽兜底路径）。

Ink 是单例，切档位时在这里同步，省得每次绘制都去改参数。
]]
function Handwrite:inkEngine()
    if not self.beautify then return nil end
    if Ink.preset ~= self.beauty_level then Ink:applyPreset(self.beauty_level) end
    return Ink
end

function Handwrite:setBeautify(on)
    self.beautify = on and true or false
    G_reader_settings:saveSetting("handwrite_beautify", self.beautify)
    if self.beautify then Ink:applyPreset(self.beauty_level) end
    self:repaint()
    if self.bar then self.bar:update(true) end
end

function Handwrite:setBeautyLevel(idx)
    self.beauty_level = idx
    G_reader_settings:saveSetting("handwrite_beautify_level", idx)
    if not self.beautify then
        self.beautify = true
        G_reader_settings:saveSetting("handwrite_beautify", true)
    end
    Ink:applyPreset(idx)   -- 立刻生效，别等到下一次绘制
    self:repaint()
    if self.bar then self.bar:update(true) end
end

function Handwrite:toggleDrawing()
    self:setDrawing(not self.drawing)
end

function Handwrite:onHandwriteToggle()
    self:toggleDrawing()
    return true
end

function Handwrite:setDrawing(on)
    on = on and true or false
    if on == self.drawing then return end

    if on then
        if not self.is_reader then
            self:notify("请在打开的书里书写；或用「空白手写本」")
            return
        end
        if not self.can_capture then
            self:notify("这台设备无法接管触摸输入")
            return
        end
        if not self.bar then self:setBarShown(true) end
        if not Capture:install(function(slots) return self:onTouchFrame(slots) end) then
            self:notify("无法开启书写：触摸接管失败")
            return
        end
        self.drawing = true
        self.gov:open()       -- 再次允许 hw_refresh 的停顿补刷定时器
        self:notify("书写已开启：单指写字，双指仍是翻页/缩放", 3)
    else
        self:abortStroke()
        Capture:remove()
        self:resetContacts()
        self.drawing = false
        self:flush()
        -- 停手前把攒下的最后一块刷掉，并让兜底定时器失效（见 hw_refresh 的 close）
        self.gov:close()
        -- 「换页时」模式：停手这一次把残影清干净，书写过程中不再打断
        if self.full_mode == "page" then self:repaint("full") end
    end
    if self.bar then self.bar:update(true) end
end

function Handwrite:toggleEraser()
    self.eraser = not self.eraser
    if self.eraser and not self.drawing then
        self:setDrawing(true)
    elseif self.bar then
        self.bar:update(true)
    end
end

function Handwrite:onHandwriteEraser()
    self:toggleEraser()
    return true
end

--- 整屏刷新会黑闪一下，用来清掉局部快刷攒下的残影。默认不打断书写。
function Handwrite:setFullMode(mode)
    self.full_mode = mode
    self.full_every = tonumber(mode) or 0
    G_reader_settings:saveSetting("handwrite_full_mode", mode)
end

--- 手动整屏刷新（工具栏「刷新」按钮 / 菜单项）。
function Handwrite:fullRefresh()
    self:repaint("full")
end

function Handwrite:cyclePenWidth()
    self.pen_width_index = self.pen_width_index % 3 + 1
    G_reader_settings:saveSetting("handwrite_pen_width", self.pen_width_index)
    if self.bar then self.bar:update(true) end
end

function Handwrite:setPenWidth(idx)
    self.pen_width_index = idx
    G_reader_settings:saveSetting("handwrite_pen_width", idx)
    if self.bar then self.bar:update(true) end
end

function Handwrite:setInkShade(idx)
    self.ink_shade = idx
    G_reader_settings:saveSetting("handwrite_ink_shade", idx)
    self:repaint()
end

function Handwrite:resetContacts()
    for slot in pairs(self.contacts) do
        self.contacts[slot] = nil
    end
    self.n_contacts = 0
    self.passthrough = false
    self.draw_slot = nil
    self.pill_tap_slot = nil
    self.pill_tap_moved = false
    self.two_finger = false
    self.two_finger_down = nil
    self.two_finger_moved = false
end

-- ---------------------------------------------------------------- 触摸

--[[--
每个触摸帧调用一次，返回 true 表示把手势交给 KOReader 处理。

仲裁规则（对齐 fingerink 的触点计数锁定 + 几何放行）：
  · 单指、起点不在工具栏上      → 书写，这一串手势全部吞掉
  · 单指、起点落在工具栏上      → 整段放行，按钮 / 小胶囊照常可点
  · 两根及以上手指             → 整段放行，双指翻页 / 缩放照常，并撤销进行中的笔画
  · 写了一半才划到工具栏上     → 就地收笔并把该触点挂起，不再画到按钮上

关键点：`passthrough` 一旦锁定就持续到整段触点结束（触点计数归零）才复位。
这样 tap/swipe 手势（它们是在「抬起」那一帧才由 GestureDetector 产生出来的）
也一定落在放行的帧里，不会出现「点了没反应」。

`SUSPENDED`（-1）是 draw_slot 的挂起态：表示这根手指已经交还系统，在抬起之前
都不再参与书写，避免一笔划进工具栏后又在半路接着画。
]]
function Handwrite:onTouchFrame(slots)
    if not self.passthrough and self:dialogOnTop() then
        -- 有菜单 / 对话框压在上面时整段让路，等它关掉后书写自动恢复
        self.passthrough = true
        self:abortStroke()
    end

    local was_passthrough = self.passthrough
    -- 帧内累积的「是否放行」。passthrough 可能在帧内被 set/clear 多次
    -- （比如「按下落在胶囊上」设了 true，同帧抬起又把它 clear 成 false），
    -- 但只要这一帧里有任何一次「该放行」，整帧就必须放行 —— 否则 tap/swipe
    -- 会被自己吞掉。这是手指事件积压（按下+抬起挤同一帧）时点不到悬浮窗的根因。
    local emit = self.passthrough

    for i = 1, #slots do
        local ev = slots[i]
        local slot = ev.slot or 0
        local id = ev.id

        if id and id >= 0 then
            -- 这个 slot 之前没按下过 = 一根新手指（抬起后 contacts 会清掉）
            local is_first = self.contacts[slot] == nil
            -- 触点当前屏幕坐标（存进 contacts 供双指 tap 判定用）
            local sx, sy
            if ev.x and ev.y then sx, sy = Capture.toScreen(ev.x, ev.y) end

            if is_first then
                self.contacts[slot] = sx and { x = sx, y = sy } or true
                self.n_contacts = self.n_contacts + 1
                if self.n_contacts > 1 and not self.passthrough then
                    -- 第二根手指落下：整段交还系统，撤销进行中的笔画，开始双指 tap 跟踪
                    self.passthrough = true
                    self:abortStroke()
                    emit = true
                    self.two_finger = true
                    self.two_finger_moved = false
                    self.two_finger_down = self:twoFingerAnchor()
                end
            else
                -- 已按下但这次带着坐标：更新坐标，并判断双指是否在移动
                if sx and self.two_finger then
                    self.contacts[slot] = { x = sx, y = sy }
                    if self:twoFingerDrifted() then
                        self.two_finger_moved = true
                    end
                end
            end

            -- 只要处于放行状态，后面的触点就不再进入书写路径
            if self.passthrough then
                emit = true
                -- 胶囊点击的位移跟踪：确认它是否「原地抬起」（用于展开兜底）
                if self.pill_tap_slot == slot and ev.x and ev.y then
                    local px, py = Capture.toScreen(ev.x, ev.y)
                    if not self:inBar(px, py) then self.pill_tap_moved = true end
                end
            elseif ev.x and ev.y then
                self:onContactPoint(slot, ev.x, ev.y, is_first)
                if self.passthrough then emit = true end
            end
        else
            -- 抬起
            if self.contacts[slot] then
                self.contacts[slot] = nil
                self.n_contacts = self.n_contacts - 1
            end
            -- 双指 tap：两指都原地抬起（没移动）→ 翻下一页
            if self.two_finger and self.n_contacts <= 1 then
                local was_two = self.two_finger
                self.two_finger = false
                if was_two and not self.two_finger_moved then
                    self:twoFingerTurnPage()
                end
                self.two_finger_down = nil
                self.two_finger_moved = false
            end
            if self.n_contacts <= 0 then
                self.n_contacts = 0
                if not self.passthrough then self:endStroke() end
                self.passthrough = false
                self.draw_slot = nil
            end
            -- 在胶囊上按下又原地抬起 → 展开（兜底，见 onPillTap）
            if self.pill_tap_slot == slot then
                if not self.pill_tap_moved then self:onPillTap() end
                self.pill_tap_slot = nil
                self.pill_tap_moved = false
            end
        end
    end

    -- 放行锁定整段：tap/swipe 产生在抬起帧，必须连同抬起帧一起放行
    return emit or was_passthrough
end

--- 双指按下时，抓两根手指当前的屏幕坐标作锚点（判定是否「原地 tap」的基准）。
function Handwrite:twoFingerAnchor()
    local x1, y1, x2, y2
    for _, c in pairs(self.contacts) do
        if type(c) == "table" then
            if not x1 then x1, y1 = c.x, c.y
            else x2, y2 = c.x, c.y end
        end
    end
    return { x1 = x1, y1 = y1, x2 = x2, y2 = y2 }
end

--- 双指当前是否偏离了按下时的锚点（有位移 = 捏合缩放，不是 tap）。
function Handwrite:twoFingerDrifted()
    local a = self.two_finger_down
    if not a then return true end
    local d1, d2 = 0, 0
    local n = 0
    for _, c in pairs(self.contacts) do
        if type(c) == "table" then
            n = n + 1
            if n == 1 then
                d1 = (c.x - a.x1) ^ 2 + (c.y - a.y1) ^ 2
            elseif n == 2 then
                d2 = (c.x - a.x2) ^ 2 + (c.y - a.y2) ^ 2
            end
        end
    end
    return d1 > TWO_FINGER_TAP_SQ or d2 > TWO_FINGER_TAP_SQ
end

--- 双指同时点击 → 翻下一页（不书写）。用 KOReader 官方翻页事件 GotoViewRel。
function Handwrite:twoFingerTurnPage()
    if not self.is_reader or not self.ui then return end
    self.ui:handleEvent(Event:new("GotoViewRel", 1))
end

--- 折叠态的小胶囊被点了一下。
-- 正常路径是把手势放行给工具栏自己处理（见 Toolbar:onGesture）；这里再兜一层：
-- 胶囊只有一个功能，只要确认是「在它上面按下、又原地抬起」就直接展开并整屏刷新，
-- 手势万一没送到也不会点了没反应。展开态下它是空操作，按钮照常走手势。
function Handwrite:onPillTap()
    if self.bar and self.bar.collapsed then
        self:expandBar()
        self:fullRefresh()
    end
end

-- draw_slot 的「挂起」态：这根手指已经交还系统，抬起前不再书写
local SUSPENDED = -1

function Handwrite:onContactPoint(slot, raw_x, raw_y, is_first)
    local x, y = Capture.toScreen(raw_x, raw_y)

    -- 工具栏永远优先于书写：落在它上面的触点一律不当笔迹处理。
    if self:inBar(x, y) then
        if is_first or self.draw_slot == nil then
            -- 起手就落在工具栏上：整段交还系统，按钮 / 小胶囊才点得到
            self.passthrough = true
            self:abortStroke()
            self.pill_tap_slot = slot
            self.pill_tap_moved = false
        elseif self.draw_slot == slot then
            -- 写了一半才划过来：就地收笔，并把该触点挂起，别画到按钮上
            self:endStroke()
            self.draw_slot = SUSPENDED
        end
        return
    end

    -- 新手指落下，上一次的归属一律作废重新判定
    if is_first then self.draw_slot = nil end

    if self.draw_slot == nil then
        self.draw_slot = slot
    elseif self.draw_slot ~= slot then
        return
    end

    if self.eraser then
        self:eraseAt(x, y)
    elseif self.stroke then
        self:addPoint(x, y)
    else
        self:startStroke(x, y)
    end
end

function Handwrite:startStroke(x, y)
    local w = PEN_WIDTHS[self.pen_width_index] or 4
    self.stroke = {
        n = 1,
        w = w,
        s = self.ink_shade,
        x, y,
    }
    if self:inkEngine() then
        -- 落笔那一瞬间先点一个圆（起笔的圆头），这样手指没抬起来就有反馈。
        -- 它是 ink 输出流里的第 1 段，重绘时会被重新算出来，所以两种画法完全一致。
        self.ink_out.n = 0
        self.inkstate = Ink:newState(x, y, w * 0.5, self.ink_out)
        Render.capsuleRange(Screen.bb, self.ink_out, 1, self.ink_out.n, 0, 0,
                            self:inkColor(self.ink_shade), self:inkGray(self.ink_shade))
        -- 落笔那一瞬间强制刷一次：手指还没动就能看到墨点，第一下就有反馈
        self:refreshBox(x, y, x, y, w, true)
    end
end

function Handwrite:addPoint(x, y)
    local s = self.stroke
    local i = s.n * 2
    local px, py = s[i - 1], s[i]
    local dx, dy = x - px, y - py
    if dx * dx + dy * dy < MIN_MOVE_SQ then return end

    s[i + 1] = x
    s[i + 2] = y
    s.n = s.n + 1

    local color = self:inkColor(s.s)
    if self.inkstate then
        -- 只画最新一两段胶囊。开销只跟这一小段有关，不会随笔画变长而累积，
        -- 这是墨水屏上「跟手」的关键。
        local out = self.ink_out
        local from = out.n + 1
        if Render.feedStep(Screen.bb, Ink, self.inkstate, out, x, y,
                           color, self:inkGray(s.s)) > 0 then
            local bx0, by0, bx1, by1 = Render.segBBox(out, from, out.n, 0, 0)
            self:refreshBox(bx0, by0, bx1, by1, 2)
        end
    else
        Render.segment(Screen.bb, px, py, x, y, s.w, color)
        self:refreshBox(px, py, x, y, s.w)
    end
end

--[[--
把流式状态里还没吐出来的尾巴画完。

hw_ink 为了保平滑，每段曲线的终点取的是相邻控制点的中点，所以会滞后半个采样点；抬笔时必须调 finish 把最后那
半段补上 —— 否则屏幕上会少一小截，而且和换页时 compute 出来的结果对不上。
]]
function Handwrite:finishBeauty(s)
    if not self.inkstate then return end
    local out = self.ink_out
    local from = out.n + 1
    local color = self:inkColor(s.s)
    local added = Ink:finish(self.inkstate, out)
    if added > 0 then
        Render.capsuleRange(Screen.bb, out, from, out.n, 0, 0,
                            color, self:inkGray(s.s))
        local bx0, by0, bx1, by1 = Render.segBBox(out, from, out.n, 0, 0)
        -- 抬笔是必须立刻给结果的时刻：把最后的笔锋尾巴直接刷出来，不等节流窗口
        self:refreshBox(bx0, by0, bx1, by1, 2, true)
    end
    self.inkstate = nil
end

function Handwrite:endStroke()
    local s = self.stroke
    self.stroke = nil
    self.draw_slot = nil
    if s then self:finishBeauty(s) end
    self:flushInk()          -- 兜底：把任何还没来得及节流刷出的区域一次性补上
    if not s then return end

    if s.n == 1 and not self:inkEngine() then   -- 只点了一下，补一个点
        local color = self:inkColor(s.s)
        Render.dot(Screen.bb, s[1], s[2], s.w, color)
        self:refreshBox(s[1], s[2], s[1], s[2], s.w, true)
    end

    self.store:add(self:currentPage(), s)

    self.strokes_since_flush = self.strokes_since_flush + 1
    if self.strokes_since_flush >= FLUSH_EVERY then
        self.strokes_since_flush = 0
        self.ui.doc_settings:saveSetting(SETTING_KEY, {
            layout = self:layoutKey(),
            pages = self.store.pages,
        })
        self:flush()
    end

    -- 只有选了「每 N 笔」才在书写过程中整屏刷新，否则不打断
    if self.full_every > 0 then
        self.strokes_since_full = self.strokes_since_full + 1
        if self.strokes_since_full >= self.full_every then
            self.strokes_since_full = 0
            self:repaint("full")
        end
    end
end

function Handwrite:abortStroke()
    if not self.stroke then
        self.draw_slot = nil
        return
    end
    self.stroke = nil
    self.draw_slot = nil
    self.inkstate = nil
    self:flushInk()
    self:repaint()
end

function Handwrite:eraseAt(x, y)
    local page = self:currentPage()
    local idx = Store.hit(self.store:get(page), x, y, ERASER_RADIUS)
    if not idx then return end
    self.store:removeAt(page, idx)
    self:repaint("full")
end

function Handwrite:undo()
    if not self.is_reader then return end
    if not self.store:pop(self:currentPage()) then
        self:notify("本页没有可撤销的笔迹")
        return
    end
    self:repaint("full")
end

function Handwrite:onHandwriteUndo()
    self:undo()
    return true
end

-- ---------------------------------------------------------------- 绘制输出

--- ReaderView 的 view module 回调：每次重绘页面时把当页笔迹画上去。
function Handwrite:paintTo(bb, x, y)
    if not self.is_reader then return end
    local list = self.store:get(self:currentPage())
    if not list then return end
    local ink, out = self:inkEngine(), self.ink_out
    for i = 1, #list do
        Render.stroke(bb, list[i], x, y, self:inkColor(list[i].s),
                      self:inkGray(list[i].s), ink, out)
    end
end

function Handwrite:repaint(refresh)
    UIManager:setDirty(self.ui or self, refresh or "ui")
end

--[[--
标注一小段新墨迹「有待显示」。

像素在落笔那一刻就已经实时写进了 framebuffer，这里只是告诉调度器「这块要送上天」。
调度器会把相邻的小块并成一个矩形、按画质档位的间隔节流，并在手指停住时补刷一次，
所以既不会像逐点刷新那样把 CPU 拖垮，也不会出现「要手动点刷新才看得见」。

force=true 用于落笔 / 抬笔这类必须马上给反馈的时刻。
]]
function Handwrite:refreshBox(x0, y0, x1, y1, w, force)
    -- 这一小段新墨迹如果压到了工具栏 / 虚浮窗，得把它重新画到最上层。
    -- 书写是直写 framebuffer、绕开 UIManager 的，笔画一划过右下角就会把悬浮窗
    -- 盖掉一块；这里每次落墨都顺手补一次重绘，让悬浮窗永远压在笔迹上面。
    self:uncoverBar(x0, y0, x1, y1, w)
    self.gov:touch(x0, y0, x1, y1, (w or 2) + 2, force)
end

--- 若新墨迹的脏矩形碰到工具栏 / 虚浮窗，就把那一块标脏让 widget 重画。
-- 折叠态只有右下角小胶囊；展开态是整个按钮栏。用 getVisibleDimen 拿到的是
-- 当前真正占屏的矩形，两种状态都覆盖。刷新胶囊也要一并纳入，别被墨迹盖掉。
function Handwrite:uncoverBar(x0, y0, x1, y1, w)
    if not self.bar then return end
    local pad = (w or 2) + 2
    local bx0, by0 = math.min(x0, x1) - pad, math.min(y0, y1) - pad
    local bx1, by1 = math.max(x0, x1) + pad, math.max(y0, y1) + pad

    local function hits(d)
        if not d then return false end
        return not (bx1 < d.x or bx0 > d.x + d.w or by1 < d.y or by0 > d.y + d.h)
    end

    local d = self.bar:getVisibleDimen()
    local rd = self.bar.refresh_pill_dimen
    if hits(d) then
        UIManager:setDirty(self.bar, "ui", d)
    end
    if rd and self.bar.refresh_pill_enabled and hits(rd) then
        UIManager:setDirty(self.bar, "ui", rd)
    end
end

--- 把攒着的显示请求立刻刷出去（切换工具、抬笔、收工时用）。
-- 极速档在这里会自动换成灰阶波形：DU 会把细笔画压白，抬笔这一下不能省。
function Handwrite:flushInk()
    self.gov:finish()
end

--- 切换书写刷新画质档位。
function Handwrite:setRefreshMode(key)
    if not Refresh.MODES_BY_KEY[key] then return end
    self.refresh_mode = key
    Refresh.saveModeKey(key)
    self.gov:setMode(key)
    self:notify("书写刷新：" .. Refresh.MODES_BY_KEY[key].text
                .. "\n波形：" .. Refresh.waveName(Refresh.MODES_BY_KEY[key].kind), 3)
end

-- ---------------------------------------------------------------- 导出

local function safeName(name)
    name = ffiutil.basename(name or "note")
    name = name:gsub("%.%w+$", "")
    name = name:gsub('[\\/:*?"<>|%c]', "_")
    if name == "" then name = "note" end
    if #name > 40 then name = name:sub(1, 40) end
    return name
end

--- 把当前这一屏（书页 + 笔迹）存成 PNG。
function Handwrite:exportPagePng()
    if not self.is_reader then
        self:notify("请先打开一本书")
        return
    end
    util.makePath(SAVE_DIR)

    -- 先重绘一次页面，把工具栏盖掉，这样导出的图才干净
    pcall(function()
        if self.view and self.view.dimen and self.view.paintTo then
            self.view:paintTo(Screen.bb, 0, 0)
        end
    end)

    local page = self:currentPage()
    local name = safeName(self.ui.document.file) .. "_p" .. page
                 .. "_" .. os.date("%Y%m%d_%H%M%S") .. ".png"
    local path = SAVE_DIR .. "/" .. name
    Screen:shot(path)

    local ok = false
    local f = io.open(path, "r")
    if f then f:close(); ok = true end
    self:notify(ok and ("已导出 " .. name) or ("导出失败：" .. name))

    UIManager:setDirty(self.ui, "full")
end

-- ---------------------------------------------------------------- 手写本

function Handwrite:openNotebook()
    self:setDrawing(false)
    if Capture.installed then Capture:remove() end
    local nb = Notebook:new{}
    UIManager:show(nb, "full")
end

function Handwrite:onHandwriteNotebook()
    self:openNotebook()
    return true
end

-- ---------------------------------------------------------------- 菜单

function Handwrite:penItem(text, idx)
    return {
        text = text,
        checked_func = function() return self.pen_width_index == idx end,
        radio = true,
        callback = function() self:setPenWidth(idx) end,
    }
end

function Handwrite:inkItem(text, idx)
    return {
        text = text,
        enabled_func = function()
            return type(Blitbuffer.COLOR_WHITE) == "number"
                   and Blitbuffer.COLOR_WHITE <= 0xFF
        end,
        checked_func = function() return self.ink_shade == idx end,
        radio = true,
        callback = function() self:setInkShade(idx) end,
    }
end

function Handwrite:addToMainMenu(menu_items)
    local sub_items = {}

    if self.is_reader then
        table.insert(sub_items, {
            text_func = function()
                return self.drawing and "停止书写" or "开始书写"
            end,
            enabled_func = function() return self.can_capture end,
            callback = function() self:toggleDrawing() end,
            help_text = "开启后单指在页面上写字，双指仍然是翻页和缩放。工具栏上的「停止」随时可以退出书写。",
        })
        table.insert(sub_items, {
            text = "显示工具栏",
            enabled_func = function() return self.can_capture end,
            checked_func = function() return self.bar ~= nil end,
            check_callback_updates_menu = true,
            callback = function(touchmenu_instance)
                self:setBarShown(self.bar == nil)
                if touchmenu_instance then touchmenu_instance:updateItems() end
            end,
        })
        table.insert(sub_items, {
            text = "虚浮窗（收成右下角小图标）",
            enabled_func = function() return self.can_capture end,
            checked_func = function() return self.bar_float end,
            check_callback_updates_menu = true,
            callback = function(touchmenu_instance)
                self:setBarFloat(not self.bar_float)
                if touchmenu_instance then touchmenu_instance:updateItems() end
            end,
            help_text = "工具栏平时收成右下角一枚半透明的小胶囊，几乎不挡正文；"
                .. "要写字或换工具时点一下它就展开，一段时间没动会自动收回去。\n"
                .. "收起状态下依然可以书写 —— 单指点页面照常落笔，只有小胶囊那一小块会拦下触摸。",
        })
        do
            local opts = {}
            for i = 1, #FLOAT_DELAYS do
                local sec = FLOAT_DELAYS[i]
                opts[i] = {
                    text = sec .. " 秒",
                    radio = true,
                    checked_func = function() return self.bar_float_delay == sec end,
                    callback = function() self:setBarFloatDelay(sec) end,
                }
            end
            opts[#opts + 1] = {
                text = "永不隐藏",
                radio = true,
                checked_func = function() return self.bar_float_delay == 0 end,
                callback = function() self:setBarFloatDelay(0) end,
                help_text = "展开后一直留在屏幕上，直到你点「收起」或再点一次小图标。",
            }
            table.insert(sub_items, {
                text = "浮窗自动隐藏时间",
                sub_item_table = opts,
                help_text = "虚浮窗展开后，最后一次点击工具栏算起，过了这段时间就自动收成小胶囊。",
            })
        end
        do
            local scales = { 0.4, 0.6, 0.8, 1.0, 1.3 }
            local scale_opts = {}
            for i = 1, #scales do
                local s = scales[i]
                scale_opts[i] = {
                    text = string.format("%d%%", math.floor(s * 100 + 0.5)),
                    radio = true,
                    checked_func = function() return self.bar_scale == s end,
                    callback = function() self:setBarScale(s) end,
                }
            end
            table.insert(sub_items, {
                text = "悬浮窗大小",
                sub_item_table = scale_opts,
                help_text = "右下角小胶囊的缩放比例，默认 60%（缩小到原来的六成）。改完立即重建。",
            })
        end
        table.insert(sub_items, {
            text = "右下角刷新胶囊",
            checked_func = function() return self.refresh_pill_enabled end,
            check_callback_updates_menu = true,
            callback = function() self:setRefreshPill(not self.refresh_pill_enabled) end,
            help_text = "在书写小胶囊左侧再放一枚深色「刷」胶囊，随时一键整屏刷新，不随主胶囊收起。",
        })
        table.insert(sub_items, {
            text = "点刷新胶囊即刷新",
            checked_func = function() return self.refresh_tap_refreshes end,
            check_callback_updates_menu = true,
            callback = function() self:setRefreshTap(not self.refresh_tap_refreshes) end,
            help_text = "默认开：点一下刷新胶囊立即整屏刷新。关掉后点它不再触发刷新。",
        })
        table.insert(sub_items, {
            text = "工具栏位置",
            separator = true,
            sub_item_table = {
                {
                    text = "屏幕左侧",
                    checked_func = function() return self.bar_side == "left" end,
                    radio = true,
                    callback = function()
                        self.bar_side = "left"
                        G_reader_settings:saveSetting("handwrite_bar_side", "left")
                        self.bar_position = nil
                        G_reader_settings:delSetting("handwrite_bar_position")
                        self:rebuildBar()
                    end,
                },
                {
                    text = "屏幕右侧",
                    checked_func = function() return self.bar_side == "right" end,
                    radio = true,
                    callback = function()
                        self.bar_side = "right"
                        G_reader_settings:saveSetting("handwrite_bar_side", "right")
                        self.bar_position = nil
                        G_reader_settings:delSetting("handwrite_bar_position")
                        self:rebuildBar()
                    end,
                },
            },
        })
        table.insert(sub_items, {
            text = "笔宽",
            sub_item_table = {
                self:penItem("细", 1),
                self:penItem("中", 2),
                self:penItem("粗", 3),
            },
        })
        table.insert(sub_items, {
            text = "墨色",
            sub_item_table = {
                self:inkItem("黑", 1),
                self:inkItem("中灰", 2),
                self:inkItem("浅灰", 3),
            },
            help_text = "仅在灰度墨水屏上有效，彩色屏幕只会用黑色。",
        })
        table.insert(sub_items, {
            text = "优化字迹（笔锋 + 抗锯齿）",
            checked_func = function() return self.beautify end,
            callback = function() self:setBeautify(not self.beautify) end,
            separator = true,
            help_text = "把等宽的锯齿线改成有起笔顿、行笔轻、收笔出锋的变宽笔画，并给边缘加灰度抗锯齿。\n"
                .. "算法是逐点流式的，书写时每来一个点只画最新的一小段，开销与笔画长短无关；"
                .. "关掉则退回等宽方块，最省电最省 CPU。",
        })
        do
            local levels = {}
            for i, p in ipairs(Ink.PRESETS) do
                levels[i] = {
                    text = p.text,
                    radio = true,
                    checked_func = function() return self.beauty_level == i end,
                    callback = function()
                        self:setBeautyLevel(i)
                        UIManager:show(Notification:new{
                            text = "笔锋：" .. p.text,
                        })
                    end,
                }
            end
            table.insert(sub_items, {
                text = "笔锋强度",
                enabled_func = function() return self.beautify end,
                sub_item_table = levels,
                help_text = "越「强」，快慢之间的粗细差别越大，毛笔味越重；"
                    .. "写小字或想要干净工整的字迹时建议用「弱」。",
            })
        end
        local waves = {}
        for i = 1, #Refresh.MODES do
            local m = Refresh.MODES[i]
            table.insert(waves, {
                text = m.text,
                radio = true,
                checked_func = function() return self.refresh_mode == m.key end,
                callback = function() self:setRefreshMode(m.key) end,
                help_text = m.help_text,
                keep_menu_open = true,
            })
        end
        table.insert(sub_items, {
            text = "书写时的刷新画质",
            sub_item_table = waves,
            help_text = "决定笔尖后面那一段怎么送上屏幕。\n"
                .. "「标准」用灰阶波形，抗锯齿笔迹写完立刻可见，也不阻塞；\n"
                .. "「抗残影」画面最干净但每次更新要等控制器，写快了会跟不上手；\n"
                .. "「极速」只有纯黑白，细笔画的灰边可能要等整屏刷新才显出来。",
        })
        table.insert(sub_items, {
            text = "整屏刷新时机",
            sub_item_table = {
                {
                    text = "停止书写/换页时（推荐）",
                    checked_func = function() return self.full_mode == "page" end,
                    radio = true,
                    callback = function() self:setFullMode("page") end,
                },
                {
                    text = "永不自动刷新（只手动）",
                    checked_func = function() return self.full_mode == "off" end,
                    radio = true,
                    callback = function() self:setFullMode("off") end,
                },
                {
                    text = "每 10 笔",
                    checked_func = function() return self.full_mode == "10" end,
                    radio = true,
                    callback = function() self:setFullMode("10") end,
                },
                {
                    text = "每 30 笔",
                    checked_func = function() return self.full_mode == "30" end,
                    radio = true,
                    callback = function() self:setFullMode("30") end,
                },
                {
                    text = "每 100 笔",
                    checked_func = function() return self.full_mode == "100" end,
                    radio = true,
                    callback = function() self:setFullMode("100") end,
                },
                {
                    text = "每 300 笔",
                    checked_func = function() return self.full_mode == "300" end,
                    radio = true,
                    callback = function() self:setFullMode("300") end,
                },
                {
                    text = "每 400 笔",
                    checked_func = function() return self.full_mode == "400" end,
                    radio = true,
                    callback = function() self:setFullMode("400") end,
                },
            },
            help_text = "整屏刷新会黑闪一下，用来清掉局部快刷攒下的残影。默认只在停止书写或换页时刷一次，写字过程中不打断。",
        })
        table.insert(sub_items, {
            text = "立即整屏刷新",
            keep_menu_open = true,
            callback = function() self:fullRefresh() end,
            separator = true,
        })
        table.insert(sub_items, {
            text = "撤销本页最后一笔",
            keep_menu_open = true,
            callback = function() self:undo() end,
        })
        table.insert(sub_items, {
            text = "导出本页为 PNG",
            keep_menu_open = true,
            callback = function() self:exportPagePng() end,
            help_text = "把当前这一屏（书页连同笔迹）存到 KOReader 目录下的 notes/handwrite。",
        })
        table.insert(sub_items, {
            text = "清除本页笔迹",
            keep_menu_open = true,
            callback = function()
                if self.store:clearPage(self:currentPage()) then
                    self:repaint("full")
                else
                    self:notify("本页没有笔迹")
                end
            end,
        })
        table.insert(sub_items, {
            text = "清除整本书笔迹",
            keep_menu_open = true,
            callback = function()
                if self.store:countPages() == 0 then
                    self:notify("这本书还没有笔迹")
                    return
                end
                UIManager:show(ConfirmBox:new{
                    text = "删除这本书里的全部手写笔迹？",
                    ok_text = "删除",
                    ok_callback = function()
                        self.store:clearAll()
                        self.ui.doc_settings:delSetting(SETTING_KEY)
                        self:flush()
                        self:repaint("full")
                    end,
                })
            end,
        })
    end

    table.insert(sub_items, {
        text = "打开空白手写本",
        separator = self.is_reader,
        enabled_func = function() return self.can_capture end,
        callback = function() self:openNotebook() end,
        help_text = "一块白纸，随手涂写；写完用「存PNG」保存，可在文件管理器里查看。",
    })
    table.insert(sub_items, {
        text = "诊断信息",
        separator = true,
        keep_menu_open = true,
        callback = function()
            local info = {
                "设备：" .. tostring(Device.model or "?"),
                "屏幕：" .. Screen:getWidth() .. "x" .. Screen:getHeight()
                    .. "（旋转模式 " .. tostring(Screen:getRotationMode()) .. "）",
                "触摸接管：" .. (self.can_capture and "可用" or "不可用"),
                "书写状态：" .. (self.drawing and "开启" or "关闭")
                    .. "，钩子：" .. (Capture.installed and "已安装" or "未安装"),
                "可用波形：UI=" .. (Screen.refreshUI and "有" or "无")
                    .. "，DU=" .. (Screen.refreshFast and "有" or "无")
                    .. "，REAGL=" .. (Screen.refreshPartial and "有" or "无"),
                "当前页笔迹：" .. self.store:count(self:currentPage()) .. " 笔"
                    .. "，全书 " .. self.store:countPages() .. " 页有笔迹",
                "整屏刷新：" .. (self.full_mode == "page" and "停手/换页时"
                    or (self.full_mode == "off" and "仅手动" or ("每 " .. self.full_mode .. " 笔"))),
                "字迹美化：" .. (self.beautify
                    and ("开（笔锋 " .. (Ink.PRESETS[self.beauty_level].text or "?") .. "）")
                    or "关（等宽）"),
                "书写刷新：" .. (Refresh.MODES_BY_KEY[self.refresh_mode].text or "?")
                    .. "（实际波形 " .. Refresh.waveName(self.gov.kind) .. "）",
                "虚浮窗：" .. (self.bar_float
                    and (self.bar_float_delay > 0 and ("开（" .. self.bar_float_delay .. " 秒后自动收起）")
                         or "开（永不自动隐藏）")
                    or "关（工具栏常驻）")
                    .. "，当前：" .. (self.bar and (self.bar.collapsed and "已收起" or "已展开") or "未显示"),
                "导出目录：" .. SAVE_DIR,
                "插件版本：" .. VERSION,
            }
            UIManager:show(require("ui/widget/infomessage"):new{
                text = "手写笔记 · 诊断信息\n\n" .. table.concat(info, "\n"),
            })
        end,
        help_text = "触摸接管显示「不可用」时说明这台设备拿不到原始触点，书写功能无法开启。",
    })
    table.insert(sub_items, {
        text = "使用说明",
        keep_menu_open = true,
        callback = function()
            UIManager:show(require("ui/widget/infomessage"):new{
                text = "手写笔记\n\n"
                    .. "1. 打开书 → 更多工具 → 手写笔记 → 开始书写\n"
                    .. "2. 单指在页面上写字；双指仍然翻页、缩放\n"
                    .. "3. 工具条：书写/停止、钢笔/橡皮、笔宽、撤销、导出、隐藏\n"
                    .. "4. 笔迹存在该书的 .sdr 里，重开自动恢复\n"
                    .. "5. 想把整屏存成图片：导出 → notes/handwrite 目录\n"
                    .. "6. 长按工具条可以把它拖到顺手的位置\n"
                    .. "7. 「优化字迹」让笔画有起笔顿、行笔轻、收笔出锋；"
                    .. "嫌慢或想要等宽效果就在菜单里关掉\n"
                    .. "8. 嫌工具条挡视线：菜单里打开「虚浮窗」，它就会收成右下角一枚\n"
                    .. "   半透明小图标，点一下再展开，一段时间后自动收起（时间可自定，\n"
                    .. "   也能设成永不隐藏）\n\n"
                    .. "也可以在「手势管理器」里给这些动作绑定手势：\n"
                    .. "手写：开始/停止书写、钢笔/橡皮、撤销一笔、打开空白手写本",
            })
        end,
    })

    menu_items.handwrite = {
        text = "手写笔记",
        sorting_hint = "more_tools",
        sub_item_table = sub_items,
    }
end

return Handwrite
