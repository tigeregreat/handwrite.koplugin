-- KOReader 插件元信息。
-- name 必须与目录名 handwrite.koplugin 的前缀一致，否则 KOReader 无法识别。
return {
    name = "handwrite",
    fullname = "手写笔记",
    version = "1.7.0",
    description = "在书页上用手指直接手写批注，并可打开空白手写本；笔迹随书保存，可撤销、擦除、导出为 PNG。自带字迹美化（B 样条 + 笔锋 + 逐像素抗锯齿）、书写刷新调度（灰阶波形 + 脏矩形合并 + 节流）与虚浮窗（工具栏收成右下角半透明小图标，点击唤醒、可调时间自动收起）。",
}
