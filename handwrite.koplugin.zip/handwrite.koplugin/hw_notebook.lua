--[[--
空白手写本。

一个全屏窗口：白色画布 + 顶部两行按钮，手指直接写。阅读器内外都能打开
（文件管理器 → 工具 → 手写笔记 → 空白手写本）。

与书页手写共用 capture（原始触点）和 store（笔迹），但笔迹只存在内存里，
需要显式「存 PNG」才会落盘 —— 手写本是草稿性质，避免往磁盘乱塞文件。
保存时用 Screen:shot() 直接抓 framebuffer，因此不需要额外的图像编码依赖。
]]

local Blitbuffer = require("ffi/blitbuffer")
local Button = require("ui/widget/button")
local ConfirmBox = require("ui/widget/confirmbox")
local DataStorage = require("datastorage")
local Device = require("device")
local FrameContainer = require("ui/widget/container/framecontainer")
local Geom = require("ui/geometry")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local Notification = require("ui/widget/notification")
local Size = require("ui/size")
local UIManager = require("ui/uimanager")
local VerticalGroup = require("ui/widget/verticalgroup")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local logger = require("logger")
local util = require("util")

local Capture = require("hw_capture")
local Ink = require("hw_ink")
local Refresh = require("hw_refresh")
local Render = require("hw_render")
local Store = require("hw_store")
local Governor = Refresh.Governor

local Screen = Device.screen
local PEN_WIDTHS = { 2, 4, 7 }
local ERASER_RADIUS = 20
local SAVE_DIR = DataStorage:getFullDataDir() .. "/notes/handwrite"

local function fileExists(path)
    local f = io.open(path, "r")
    if not f then return false end
    f:close()
    return true
end

local Notebook = WidgetContainer:extend{
    covers_fullscreen = true,
}

function Notebook:init()
    self.w = Screen:getWidth()
    self.h = Screen:getHeight()

    local bbtype
    if Screen.bb and Screen.bb.getType then
        bbtype = Screen.bb:getType()
    end
    -- 与屏幕同类型，blitFrom 才是纯内存拷贝，速度最快
    self.bb = Blitbuffer.new(self.w, self.h, bbtype)
    self.bb:fill(Blitbuffer.COLOR_WHITE)

    self.pages = {}                 -- { [页码] = { stroke, ... } }
    self.cur = 1
    self.unsaved = false
    self.strokes_since_full = 0
    self.pen_width_index = 2        -- 1=细 2=中 3=粗
    self.eraser = false
    -- 书写刷新调度器：选波形 + 合并脏矩形 + 节流 + 停手补刷（详见 hw_refresh.lua）
    self.refresh_mode = Refresh.loadModeKey()
    self.gov = Governor:new{
        mode_key = self.refresh_mode,
        -- 笔迹画在离屏画布 self.bb 上，刷之前必须先把这块区域抄进 framebuffer
        sync = function(x, y, w, h) Screen.bb:blitFrom(self.bb, x, y, x, y, w, h) end,
    }
    -- 字迹美化：变宽笔锋 + 圆形笔尖 + 灰度抗锯齿。关掉就退回等宽方块，
    -- 是最省 CPU 的兜底路径。
    self.beautify = G_reader_settings:readSetting("handwrite_beautify") ~= false
    self.beauty_level = G_reader_settings:readSetting("handwrite_beautify_level")
                        or Ink.DEFAULT_PRESET
    self.ink_out = {}               -- 重绘时复用的临时数组，避免每条笔画分配
    -- 整屏刷新时机（会黑闪一下，用来清掉快刷残留的残影）：
    --   "page" = 只在换页时刷（默认）  "off" = 只手动  数字 = 每 N 笔
    self:setFullMode(G_reader_settings:readSetting("handwrite_full_mode") or "page")

    self.contacts = {}
    self.n_contacts = 0
    self.draw_slot = nil
    self.stroke = nil
    self.abandon = false            -- 本次触摸已交还给系统（点在工具栏上/多指）

    self:buildBar()
    self[1] = self.bar              -- 让按钮成为子节点，才能收到点击事件

    self.dimen = Geom:new{ x = 0, y = 0, w = self.w, h = self.h }

    if not Capture:install(function(slots) return self:onTouchFrame(slots) end) then
        logger.warn("handwrite: 手写本无法接管触摸输入")
    end
end

-- -------------------------------------------------------------- 工具栏

function Notebook:mkButton(text, width, cb, hold_cb)
    return Button:new{
        text = text,
        width = width,
        radius = Size.radius.button,
        bordersize = Size.border.thin,
        padding = Size.padding.small,
        text_font_face = "smallinfofont",
        text_font_size = 18,
        text_font_bold = false,
        show_parent = self,
        callback = cb,
        hold_callback = hold_cb,
    }
end

function Notebook:buildBar()
    local bw = math.floor(self.w / 7) - 2 * Size.padding.small

    self.tool_btn = self:mkButton("钢笔", bw, function() self:toggleEraser() end)
    self.width_btn = self:mkButton("中", bw, function() self:cyclePenWidth() end)
    -- 短按开关美化，长按循环笔锋强度
    self.beauty_btn = self:mkButton("美化", bw,
        function() self:toggleBeautify() end,
        function() self:cycleBeautyLevel() end)
    self.undo_btn = self:mkButton("撤销", bw, function() self:undo() end)
    self.clear_btn = self:mkButton("清空", bw, function() self:clearPage() end)
    -- 短按整屏刷新，长按切换书写时的刷新画质（波形），不必回菜单去改
    self.refresh_btn = self:mkButton("刷新", bw,
        function() self:fullRefresh() end,
        function() self:cycleRefreshMode() end)
    self.save_btn = self:mkButton("存PNG", bw, function() self:savePage() end)

    self.prev_btn = self:mkButton("◀上页", bw, function() self:goPage(self.cur - 1) end)
    self.page_btn = self:mkButton("1/1", bw, function() self:newPage() end)
    self.next_btn = self:mkButton("下页▶", bw, function() self:goPage(self.cur + 1) end)
    self.new_btn = self:mkButton("新页", bw, function() self:newPage() end)
    self.saveall_btn = self:mkButton("存全部", bw, function() self:saveAll() end)
    self.close_btn = self:mkButton("关闭", bw, function() self:tryClose() end)

    self.bar = FrameContainer:new{
        background = Blitbuffer.COLOR_WHITE,
        bordersize = Size.border.thin,
        radius = Size.radius.window,
        padding = Size.padding.small,
        margin = 0,
        VerticalGroup:new{
            align = "center",
            HorizontalGroup:new{
                align = "center",
                self.tool_btn, self.width_btn, self.beauty_btn,
                self.undo_btn, self.clear_btn, self.refresh_btn, self.save_btn,
            },
            HorizontalGroup:new{
                align = "center",
                self.prev_btn, self.page_btn, self.next_btn,
                self.new_btn, self.saveall_btn, self.close_btn,
            },
        },
    }
    local size = self.bar:getSize()
    self.bar_w, self.bar_h = size.w, size.h
end

--- full_mode: "page"（换页时刷） / "off"（只手动） / 数字字符串（每 N 笔）
function Notebook:setFullMode(mode)
    self.full_mode = mode
    self.full_every = tonumber(mode) or 0
    G_reader_settings:saveSetting("handwrite_full_mode", mode)
end

--- 手动整屏刷新：把快刷攒下的残影一次擦干净。
function Notebook:fullRefresh()
    UIManager:setDirty(self, "full")
end

--- 长按「刷新」按钮循环切换书写画质档位。
function Notebook:cycleRefreshMode()
    local order = {}
    for i = 1, #Refresh.MODES do order[i] = Refresh.MODES[i].key end
    local next_idx = 1
    for i = 1, #order do
        if order[i] == self.refresh_mode then next_idx = i % #order + 1 break end
    end
    self:setRefreshMode(order[next_idx])
end

function Notebook:setRefreshMode(key)
    if not Refresh.MODES_BY_KEY[key] then return end
    self.refresh_mode = key
    Refresh.saveModeKey(key)
    self.gov:setMode(key)
    UIManager:show(Notification:new{
        text = "书写刷新：" .. Refresh.MODES_BY_KEY[key].text
               .. "\n波形：" .. Refresh.waveName(self.gov.kind),
        timeout = 3,
    })
end

-- -------------------------------------------------------------- 字迹美化

--[[--
返回绘制用的美化引擎，关闭时返回 nil（走等宽兜底路径）。

Ink 是单例，切档位时在这里同步，省得每次绘制都去改参数。
]]
function Notebook:inkEngine()
    if not self.beautify then return nil end
    if Ink.preset ~= self.beauty_level then Ink:applyPreset(self.beauty_level) end
    return Ink
end

function Notebook:toggleBeautify()
    self.beautify = not self.beautify
    G_reader_settings:saveSetting("handwrite_beautify", self.beautify)
    if self.beautify then Ink:applyPreset(self.beauty_level) end
    self:repaintPage()
    self:update()
    UIManager:show(Notification:new{
        text = self.beautify and "字迹美化：开" or "字迹美化：关（等宽）",
    })
end

function Notebook:cycleBeautyLevel()
    self.beauty_level = self.beauty_level % #Ink.PRESETS + 1
    G_reader_settings:saveSetting("handwrite_beautify_level", self.beauty_level)
    if not self.beautify then self.beautify = true
        G_reader_settings:saveSetting("handwrite_beautify", true) end
    Ink:applyPreset(self.beauty_level)   -- 立刻生效
    self:repaintPage()
    self:update()
    UIManager:show(Notification:new{
        text = "笔锋：" .. (Ink.PRESETS[self.beauty_level].text or ""),
    })
end

function Notebook:update()
    self.tool_btn:setText(self.eraser and "橡皮" or "钢笔")
    self.width_btn:setText(({ "细", "中", "粗" })[self.pen_width_index] or "中")
    self.beauty_btn:setText(self.beautify and "美化" or "美化·关")
    self.page_btn:setText(string.format("%d/%d", self.cur, math.max(1, self:maxPage(), self.cur)))
    UIManager:setDirty(self, "ui", Geom:new{ x = 0, y = 0, w = self.bar_w, h = self.bar_h })
end

--- 顶部工具栏占的矩形；落在里面的触摸交还给系统，用来点按钮。
function Notebook:inBar(x, y)
    return x >= 0 and x <= self.bar_w and y >= 0 and y <= self.bar_h
end

-- -------------------------------------------------------------- 输入

--[[--
注意 was_abandon：tap 手势是 GestureDetector 在「抬起」那一帧才产生的，而抬起帧
会把 self.abandon 复位。若只返回复位后的值，点按钮的最后一步就被吞掉了，按钮永远
点不动（参考 fingerink 的 ADR-8：放行必须锁定整个触点序列，含抬起帧）。
]]
function Notebook:onTouchFrame(slots)
    local was_abandon = self.abandon
    for i = 1, #slots do
        local ev = slots[i]
        local slot = ev.slot or 0
        local id = ev.id

        if id and id >= 0 then
            if not self.contacts[slot] then
                self.contacts[slot] = true
                self.n_contacts = self.n_contacts + 1
            end
            if self.n_contacts > 1 then
                -- 多指：放弃这一笔，但也不放行（否则会穿透到下层翻页）
                self.abandon = true
                self:abortStroke()
            elseif not self.abandon and ev.x and ev.y then
                local x, y = Capture.toScreen(ev.x, ev.y)
                if self.draw_slot == nil then
                    if self:inBar(x, y) then
                        self.abandon = true
                        self:abortStroke()
                    else
                        self.draw_slot = slot
                    end
                end
                if self.draw_slot == slot and not self.abandon then
                    self:onPoint(x, y)
                end
            end
        else
            if self.contacts[slot] then
                self.contacts[slot] = nil
                self.n_contacts = self.n_contacts - 1
            end
            if self.n_contacts <= 0 then
                self.n_contacts = 0
                if not self.abandon then self:endStroke() end
                self.abandon = false
                self.draw_slot = nil
            end
        end
    end

    -- 起点落在工具栏上时放行（含抬起帧），其余一律吞掉
    return self.abandon or was_abandon
end

function Notebook:onPoint(x, y)
    if self.eraser then
        local list = self.pages[self.cur]
        local idx = Store.hit(list, x, y, ERASER_RADIUS)
        if idx then
            table.remove(list, idx)
            if #list == 0 then self.pages[self.cur] = nil end
            self.unsaved = true
            self:repaintPage()
        end
        return
    end

    local w = PEN_WIDTHS[self.pen_width_index] or 4
    local color = self:inkColor()
    local gray = self:inkGray()

    if not self.stroke then
        self.stroke = { n = 1, w = w, s = 1, x, y }
        if self:inkEngine() then
            -- 落笔那一瞬先点一个圆（起笔的圆头）。只画 self.bb：refreshBox 会把这
            -- 一小块同步进 framebuffer，既省掉一半绘制开销，也保证显存里的东西永远
            -- 以画布为准 —— 别的 widget 万一把这块盖脏了，下一次局部刷新就修回来。
            self.ink_out.n = 0
            self.inkstate = Ink:newState(x, y, w * 0.5, self.ink_out)
            Render.capsuleRange(self.bb, self.ink_out, 1, self.ink_out.n,
                                0, 0, color, gray)
            -- 落笔那一瞬间强制刷一次：手指还没动就能看到墨点
            self:refreshBox(x, y, x, y, w, true)
        end
        return
    end

    local s = self.stroke
    local i = s.n * 2
    local px, py = s[i - 1], s[i]
    local dx, dy = x - px, y - py
    if dx * dx + dy * dy < 4 then return end   -- 抖动过滤：位移小于 2px 不记点

    s[i + 1] = x
    s[i + 2] = y
    s.n = s.n + 1

    if self.inkstate then
        -- 只画最新一两段胶囊：整条笔画从不重画，所以每帧的开销只跟这一小段有关，
        -- 跟这一笔写了多久无关。
        local out = self.ink_out
        local from = out.n + 1
        if Render.feedStep(self.bb, Ink, self.inkstate, out, x, y,
                           color, gray) > 0 then
            local bx0, by0, bx1, by1 = Render.segBBox(out, from, out.n, 0, 0)
            self:refreshBox(bx0, by0, bx1, by1, 2)
        end
    else
        Render.segment(self.bb, px, py, x, y, s.w, color)
        self:refreshBox(px, py, x, y, s.w)
    end
end

--[[--
把流式状态里还没吐出来的尾巴画完。

hw_ink 为了保平滑，每段曲线的终点取的是相邻控制点的中点，所以会滞后半个采样点；抬笔时必须调 finish 把最后半段补上，
否则屏幕上会少一小截，而且和换页重绘（走 compute）的结果对不上。
]]
function Notebook:finishBeauty(s)
    if not self.inkstate then return end
    local out = self.ink_out
    local from = out.n + 1
    local added = Ink:finish(self.inkstate, out)
    if added > 0 then
        local color, gray = self:inkColor(), self:inkGray()
        Render.capsuleRange(self.bb, out, from, out.n, 0, 0, color, gray)
        local bx0, by0, bx1, by1 = Render.segBBox(out, from, out.n, 0, 0)
        -- 抬笔必须立刻给结果：把最后的笔锋尾巴直接刷出来，不等节流窗口
        self:refreshBox(bx0, by0, bx1, by1, 2, true)
    end
    self.inkstate = nil
end

function Notebook:endStroke()
    local s = self.stroke
    self.stroke = nil
    if s then self:finishBeauty(s) end
    self:flushInk()          -- 兜底：把还没来得及节流刷出的区域一次性补上
    if not s then return end

    if s.n == 1 and not self:inkEngine() then   -- 只点了一下：补一个点
        local color = self:inkColor()
        Render.dot(self.bb, s[1], s[2], s.w, color)
        self:refreshBox(s[1], s[2], s[1], s[2], s.w, true)
    end

    if not self.pages[self.cur] then self.pages[self.cur] = {} end
    local list = self.pages[self.cur]
    list[#list + 1] = s
    self.unsaved = true

    -- 只有用户选了「每 N 笔」才在书写过程中整屏刷新；
    -- 默认（换页时）不打断书写，换页那次整刷会把残影一起清掉。
    if self.full_every > 0 then
        self.strokes_since_full = self.strokes_since_full + 1
        if self.strokes_since_full >= self.full_every then
            self.strokes_since_full = 0
            self:fullRefresh()
        end
    end
    self:update()
end

function Notebook:abortStroke()
    if self.stroke then
        self.stroke = nil
        self.inkstate = nil
        self:flushInk()
        self:repaintPage()
    end
end

function Notebook:inkColor()
    return Blitbuffer.COLOR_BLACK
end

--- 抗锯齿用的墨色灰度值（0 = 纯黑）。手写本只有纯黑一种墨。
function Notebook:inkGray()
    return 0
end

-- -------------------------------------------------------------- 页面

--- 有笔迹的最大页码。pages 是稀疏表，用 # 不可靠。
function Notebook:maxPage()
    local m = 0
    for k in pairs(self.pages) do
        if type(k) == "number" and k > m then m = k end
    end
    return m
end

--- 新建一页并跳过去；当前页还是空白时不会重复建。
function Notebook:newPage()
    local n = self:maxPage() + 1
    if self.cur == n then
        UIManager:show(Notification:new{ text = "当前已经是新的空白页" })
        return
    end
    self.stroke = nil
    self.cur = n
    self:repaintPage()
    self:update()
end

function Notebook:goPage(n)
    if n < 1 then n = 1 end
    local last = self:maxPage() + 1
    if n > last then n = last end
    if n ~= self.cur then
        self.stroke = nil
        self.cur = n
        self:repaintPage()   -- 换页本身就是整屏刷新，残影顺带清掉
    end
    self:update()
end

function Notebook:clearPage()
    if not self.pages[self.cur] then
        UIManager:show(Notification:new{ text = "本页是空的" })
        return
    end
    self.pages[self.cur] = nil
    if self.cur > 1 and self.cur > self:maxPage() then
        self.cur = math.max(1, self:maxPage())
    end
    self.unsaved = true
    self:repaintPage()
    self:update()
end

function Notebook:undo()
    local list = self.pages[self.cur]
    if not list or #list == 0 then
        UIManager:show(Notification:new{ text = "没有可撤销的笔迹" })
        return
    end
    list[#list] = nil
    if #list == 0 then self.pages[self.cur] = nil end
    self.unsaved = true
    self:repaintPage()
    self:update()
end

function Notebook:toggleEraser()
    self.eraser = not self.eraser
    self:update()
end

function Notebook:cyclePenWidth()
    self.pen_width_index = self.pen_width_index % 3 + 1
    self:update()
end

--- 把当前页重画到画布并整屏刷新。
function Notebook:repaintPage()
    self:renderPage(self.bb, self.cur)
    UIManager:setDirty(self, "full")
end

--- 把第 n 页画到给定画布（先铺白底）。
function Notebook:renderPage(bb, n)
    bb:fill(Blitbuffer.COLOR_WHITE)
    local list = self.pages[n]
    if list then
        local color, gray = self:inkColor(), self:inkGray()
        local ink, out = self:inkEngine(), self.ink_out
        for i = 1, #list do
            Render.stroke(bb, list[i], 0, 0, color, gray, ink, out)
        end
    end
end

-- -------------------------------------------------------------- 导出

--- 把第 n 页存成 PNG：先把画布铺满 framebuffer，再 shot。
-- shot 读的是显存内容，因此不必等一次真实刷新，也不必先隐藏工具栏。
function Notebook:savePageAs(n, path)
    self:renderPage(self.bb, n)
    Screen.bb:blitFrom(self.bb, 0, 0, 0, 0, self.w, self.h)
    Screen:shot(path)
    return fileExists(path)
end

function Notebook:savePage()
    util.makePath(SAVE_DIR)
    local name = "note_" .. os.date("%Y%m%d_%H%M%S") .. "_p" .. self.cur .. ".png"
    local path = SAVE_DIR .. "/" .. name
    if self:savePageAs(self.cur, path) then
        UIManager:show(Notification:new{ text = "已保存 " .. name })
    else
        UIManager:show(Notification:new{ text = "保存失败：" .. name })
    end
    self:repaintPage()
end

function Notebook:saveAll()
    if self:maxPage() == 0 then
        UIManager:show(Notification:new{ text = "还没有写任何东西" })
        return
    end
    util.makePath(SAVE_DIR)
    local stamp = os.date("%Y%m%d_%H%M%S")
    local ok, fail = 0, 0
    for n = 1, self:maxPage() do
        if self.pages[n] then
            local path = SAVE_DIR .. "/note_" .. stamp .. "_p" .. n .. ".png"
            if self:savePageAs(n, path) then ok = ok + 1 else fail = fail + 1 end
        end
    end
    UIManager:show(Notification:new{
        text = string.format("已存 %d 页%s → notes/handwrite", ok,
                             fail > 0 and ("（失败 " .. fail .. " 页）") or ""),
    })
    self.unsaved = false
    self:repaintPage()
end

-- -------------------------------------------------------------- 生命周期

function Notebook:paintTo(bb, x, y)
    bb:blitFrom(self.bb, x, y, 0, 0, self.w, self.h)
    self.bar:paintTo(bb, x, y)
end

--- 手势一律吞掉：手写本是全屏的，漏到下层的手势会造成莫名其妙的翻页。
-- 按钮是子节点，会先于这里处理手势，所以不影响点击。
function Notebook:onGesture()
    return true
end

function Notebook:onCloseWidget()
    Capture:remove()
    -- 窗口已关，兜底定时器再触发就是往别人的画面里刷了，这里让它失效
    self.gov:close()
end

function Notebook:tryClose()
    if not self.unsaved then
        Capture:remove()
        UIManager:close(self)
        return
    end
    -- 确认框要靠触摸点击，先把钩子卸掉，否则按钮收不到事件
    Capture:remove()
    UIManager:show(ConfirmBox:new{
        text = "手写本里还有没保存的内容，保存为 PNG 吗？",
        ok_text = "保存",
        cancel_text = "直接关闭",
        ok_callback = function()
            self:saveAll()
            UIManager:close(self)
        end,
        cancel_callback = function()
            UIManager:close(self)
        end,
    })
end

--[[--
标注一小段新墨迹「有待显示」。

像素在落笔那一刻已经写进离屏画布 self.bb，这里交给调度器决定什么时候把它送上天：
相邻的小块会被并成一个矩形，按画质档位的间隔节流，手指停住时再补刷一次。
因此既不会像逐点刷新那样拖垮 CPU，也不会出现「要手动点刷新才看得见」。

force=true 用于落笔 / 抬笔这类必须马上给反馈的时刻。
]]
function Notebook:refreshBox(x0, y0, x1, y1, w, force)
    self.gov:touch(x0, y0, x1, y1, (w or 2) + 2, force)
end

--- 把攒着的显示请求立刻刷出去（抬笔、收工时用）。
-- 极速档在这里会自动换成灰阶波形：DU 会把细笔画压白，抬笔这一下不能省。
function Notebook:flushInk()
    self.gov:finish()
end

--- 全画布重刷（换页、清页、手动刷新时用）。
function Notebook:repaintCanvas()
    Screen.bb:blitFrom(self.bb, 0, 0, 0, 0, self.w, self.h)
    if Screen.refreshPartial then
        Screen:refreshPartial(0, 0, self.w, self.h)
    else
        Screen:refreshFull(0, 0, self.w, self.h)
    end
end

return Notebook
