--[[--
侧边工具栏 + 虚浮窗。

它是一个正常的 KOReader widget，浮在 ReaderUI 之上，所以按钮照常接收点击；
而书写模式会把单指触摸全部吞掉 —— 因此在捕获层里，凡是起点落在工具栏范围内
的触点都会原样放行（见 main.lua:onTouchFrame）。「书写中却没有办法停下来」
这类死锁由此避免：工具栏可见是书写的必要条件。

处于最上层也意味着 UIManager 只把输入事件给它一个窗口，落在工具栏空白处
的手势必须手动转发给下面的窗口，否则菜单、对话框全都点不动。

【虚浮窗】折叠态下按钮全部收起，只剩右下角一枚半透明小胶囊（「笔」）：
  · 画在工具栏自己的 paintTo 里，但靠 UIManager 的 alpha 机制保证下层已经
    重绘过 —— 见下面 PILL_ALPHA 的注释，否则半透明会越叠越白；
  · 折叠时不把事件下发给子控件，避免点到「看不见」的按钮；
  · 点一下小胶囊 → plugin:expandBar() 唤出完整工具栏，倒计时结束后自动收起。
]]

local Blitbuffer = require("ffi/blitbuffer")
local Button = require("ui/widget/button")
local Device = require("device")
local Font = require("ui/font")
local FrameContainer = require("ui/widget/container/framecontainer")
local Geom = require("ui/geometry")
local MovableContainer = require("ui/widget/container/movablecontainer")
local Notification = require("ui/widget/notification")
local Size = require("ui/size")
local TextWidget = require("ui/widget/textwidget")
local UIManager = require("ui/uimanager")
local VerticalGroup = require("ui/widget/verticalgroup")
local WidgetContainer = require("ui/widget/container/widgetcontainer")

local Screen = Device.screen

local BAR_WIDTH_RATIO = 0.13
local BAR_FONT_SIZE = 18

-- 折叠后的小胶囊（数值是 scaleBySize 之前的基准）
local PILL_W = 56
local PILL_H = 40
local PILL_FONT_SIZE = 22
local PILL_BG_GRAY, PILL_BG_ALPHA = 0xFF, 0xB4   -- 白底约 70%
local PILL_BD_GRAY, PILL_BD_ALPHA = 0x00, 0xA0   -- 深色描边约 63%

-- 右下角「刷新」胶囊：紧挨主胶囊左侧（底边对齐，留一条缝）。
-- 外观和主胶囊一致：白底半透明 + 深色描边 + 黑字，视觉上成对出现。
local REFRESH_PILL_W = 40
local REFRESH_PILL_H = 40
local REFRESH_PILL_FONT_SIZE = 20
local REFRESH_PILL_GAP = 8          -- 和主胶囊之间留的缝（scaleBySize 之前）
local REFRESH_BG_GRAY, REFRESH_BG_ALPHA = 0xFF, 0xB4   -- 白底约 70%（同主胶囊）
local REFRESH_BD_GRAY, REFRESH_BD_ALPHA = 0x00, 0xA0   -- 深色描边约 63%（同主胶囊）

-- 触摸命中余量（scaleBySize 之前），手指点小胶囊时用得上。
local TOUCH_SLOP = 12

--[[--
告诉 UIManager「这个窗口是半透明的」。

UIManager:setDirty 看到 widget.alpha 是 0<alpha<1 的数，就会把它下面的窗口
全部标脏 —— 混合前背景一定是最新的，半透明才不会一遍遍叠上去越来越白。
代价是每次刷新浮窗都会连页面一起重绘，所以只在折叠态挂上这个值。
]]
local PILL_ALPHA = 0.7

-- 只把 sendEvent 类的输入转发给下层窗口；其余事件每个窗口本来都会收到。
local INPUT_HANDLERS = {
    onGesture = true,
    onKeyPress = true,
    onKeyRepeat = true,
    onKeyRelease = true,
}

local Toolbar = WidgetContainer:extend{
    plugin = nil,     -- Handwrite 实例
    side = "right",
    position = nil,   -- {x=, y=} 用户拖动后的位置
    collapsed = false,
    full_dimen = nil, -- 展开态：整条按钮栏
    pill_dimen = nil, -- 折叠态：右下角小胶囊
}

-- 拖动结束后把最终位置回传给插件保存。
local MovableBar = MovableContainer:extend{}

function MovableBar:_moveBy(dx, dy, restrict_to_screen)
    MovableContainer._moveBy(self, dx, dy, restrict_to_screen)
    if self.on_move then self.on_move(self) end
end

-- ------------------------------------------------------------ 半透明小胶囊

local function color8a(gray, alpha)
    if Blitbuffer.Color8A then return Blitbuffer.Color8A(gray, alpha) end
    return Blitbuffer.COLOR_WHITE
end

--[[--
能不能走 blitbuffer 的 C 快路径（lightenRect / darkenRect 内部用）。

C 版混合不处理旋转，横屏时会画错位置，所以只在正屏时用；其余情况退回
paintRect + setPixelBlend（走 getPhysicalCoordinates，旋转也对）。
]]
local function canFastBlend(bb)
    if not (bb.lightenRect and bb.darkenRect) then return false end
    if Screen.getRotationMode and Screen:getRotationMode() ~= 0 then return false end
    return true
end

--- 在 (x, y) 画一行宽 w、透明度 alpha 的像素。cov 是这一行在圆角上的覆盖率。
local function blendRow(bb, x, y, w, gray, alpha, fast, cov)
    if w <= 0 then return end
    if cov ~= nil and cov < 1 then
        -- 边缘那一两行按覆盖率衰减，免得圆角看着是台阶
        if cov <= 0 then return end
        alpha = math.floor(alpha * cov + 0.5)
        if alpha <= 0 then return end
    end
    if fast then
        local by = alpha / 255
        if gray >= 0xFF then
            bb:lightenRect(x, y, w, 1, by)
        else
            bb:darkenRect(x, y, w, 1, by)
        end
    else
        bb:paintRect(x, y, w, 1, color8a(gray, alpha), bb.setPixelBlend or bb.setPixel)
    end
end

--- 胶囊最上 / 最下一行：左右两端各按覆盖率淡出一小段，圆头才不会有台阶。
-- 只在这一行用，用来换更好的圆角，代价可忽略。
local function blendCapRow(bb, x, y, w, gray, alpha, fast, cov)
    if w <= 0 then return end
    if cov <= 0 then return end
    local e = math.min(w, math.max(1, math.ceil(cov)))
    local fc = cov - math.floor(cov)
    if fc <= 0 then
        blendRow(bb, x, y, w, gray, alpha, fast, 1)
    else
        if w <= 2 * e then
            blendRow(bb, x, y, w, gray, alpha, fast, cov)
        else
            blendRow(bb, x, y, e, gray, alpha, fast, fc)
            blendRow(bb, x + e, y, w - 2 * e, gray, alpha, fast, 1)
            blendRow(bb, x + w - e, y, e, gray, alpha, fast, fc)
        end
    end
end

--[[--
半透明胶囊（左右两端是半圆）：一圈描边 + 中间填底，一趟画完。

逐行算出这一行的左右内缩量，再分三段（左边框 / 底 / 右边框）混合。
必须一趟画完：如果先整块描边再整块填底，半透明的底会透出下面那层深色，
中间就不是「透过来的纸」而是被描边染灰的一块。
]]
local function blendPill(bb, x, y, w, h, bw, bg_gray, bg_alpha, bd_gray, bd_alpha, fast)
    if w <= 0 or h <= 0 then return end
    local r = math.max(1, math.floor(h / 2))
    local hx = h / 2
    for py = 0, h - 1 do
        local dy = math.abs(py + 0.5 - hx)
        local cov = 1
        if dy > r - 1 then cov = r - dy end    -- 上下两端按覆盖率淡出
        if cov > 0 then
            local d2 = r * r - dy * dy
            local inset = d2 > 0 and math.ceil(r - math.sqrt(d2)) or r
            local rw = w - 2 * inset
            if rw > 0 then
                local x0, yy = x + inset, y + py
                -- 第一行 / 最后一行：整行短一截，两端都要淡出
                if py == 0 or py == h - 1 then
                    blendCapRow(bb, x0, yy, rw, bd_gray, bd_alpha, fast, cov)
                elseif rw <= 2 * bw then
                    blendRow(bb, x0, yy, rw, bd_gray, bd_alpha, fast, cov)
                else
                    blendRow(bb, x0, yy, bw, bd_gray, bd_alpha, fast, cov)
                    blendRow(bb, x0 + bw, yy, rw - 2 * bw, bg_gray, bg_alpha, fast, cov)
                    blendRow(bb, x0 + rw - bw, yy, bw, bd_gray, bd_alpha, fast, cov)
                end
            end
        end
    end
end

--- 悬浮窗缩放系数（默认 0.6，即缩小到原来的 60%）。由插件菜单设置。
function Toolbar:pillScale()
    local s = self.plugin and self.plugin.bar_scale
    return type(s) == "number" and s > 0 and s or 0.6
end

--- 右下角那枚小胶囊的位置（跟着屏幕尺寸走，转屏后由 rebuildBar 重建）。
-- 尺寸按 bar_scale 缩放，让胶囊默认小一号、也能按需调大。
function Toolbar:pillDimen()
    local scale = self:pillScale()
    local w = Screen:scaleBySize(PILL_W) * scale
    local h = Screen:scaleBySize(PILL_H) * scale
    local pad = Size.padding.large or Screen:scaleBySize(10)
    return Geom:new{
        x = Screen:getWidth() - w - pad,
        y = Screen:getHeight() - h - pad,
        w = w,
        h = h,
    }
end

--- 「刷新」胶囊的几何：紧挨主胶囊左侧，底边对齐，中间留一条缝，不重叠。
-- 高度跟随主胶囊缩放，宽度也按同样比例缩放，视觉上协调。
function Toolbar:refreshPillDimen()
    local main = self.pill_dimen or self:pillDimen()
    local scale = self:pillScale()
    local w = Screen:scaleBySize(REFRESH_PILL_W) * scale
    local h = Screen:scaleBySize(REFRESH_PILL_H) * scale
    local gap = Screen:scaleBySize(REFRESH_PILL_GAP)
    return Geom:new{
        x = main.x - w - gap,
        y = main.y + (main.h - h),   -- 底边对齐
        w = w,
        h = h,
    }
end

function Toolbar:paintPill(bb)
    local d = self.pill_dimen
    if not d then return end
    local fast = canFastBlend(bb)
    local bw = math.max(1, Size.border.thin or 1)
    blendPill(bb, d.x, d.y, d.w, d.h, bw,
              PILL_BG_GRAY, PILL_BG_ALPHA, PILL_BD_GRAY, PILL_BD_ALPHA, fast)
    if self.pill_text then
        local ts = self.pill_text:getSize()
        self.pill_text:paintTo(bb,
            d.x + math.floor((d.w - ts.w) / 2),
            d.y + math.floor((d.h - ts.h) / 2))
    end
end

--- 刷新胶囊：白底黑字「刷」，和主胶囊一样半透明、圆角、描边。
function Toolbar:paintRefreshPill(bb)
    if not (self.refresh_pill_enabled and self.refresh_pill_dimen) then return end
    local d = self.refresh_pill_dimen
    local fast = canFastBlend(bb)
    local bw = math.max(1, Size.border.thin or 1)
    blendPill(bb, d.x, d.y, d.w, d.h, bw,
              REFRESH_BG_GRAY, REFRESH_BG_ALPHA, REFRESH_BD_GRAY, REFRESH_BD_ALPHA, fast)
    if self.refresh_pill_text then
        local ts = self.refresh_pill_text:getSize()
        self.refresh_pill_text:paintTo(bb,
            d.x + math.floor((d.w - ts.w) / 2),
            d.y + math.floor((d.h - ts.h) / 2))
    end
end

-- ---------------------------------------------------------------- 构造

function Toolbar:mkButton(text, width, cb)
    return Button:new{
        text = text,
        width = width,
        radius = Size.radius.button,
        bordersize = Size.border.thin,
        padding = Size.padding.small,
        text_font_face = "smallinfofont",
        text_font_size = BAR_FONT_SIZE,
        text_font_bold = false,
        show_parent = self,
        readonly = true,   -- 让长按冒泡给 MovableBar，实现拖动
        callback = function()
            -- 碰了工具栏就把「自动收起」的倒计时重新拨一遍
            if self.plugin then self.plugin:pokeFloatBar() end
            cb()
        end,
    }
end

function Toolbar:init()
    local p = self.plugin
    local w = math.floor(Screen:getWidth() * BAR_WIDTH_RATIO)
    if w < Screen:scaleBySize(64) then w = Screen:scaleBySize(64) end
    self.button_width = w

    self.draw_btn = self:mkButton(self:drawText(), w, function()
        p:toggleDrawing()
    end)
    self.tool_btn = self:mkButton(self:toolText(), w, function()
        p:toggleEraser()
    end)
    self.width_btn = self:mkButton(self:widthText(), w, function()
        p:cyclePenWidth()
    end)
    -- 字迹美化的开关；笔锋强度在「手写笔记」菜单里调（这里长按要留给拖动）
    self.beauty_btn = self:mkButton(self:beautyText(), w, function()
        p:setBeautify(not p.beautify)
        UIManager:show(Notification:new{
            text = p.beautify and "字迹美化：开" or "字迹美化：关（等宽）",
        })
    end)
    self.undo_btn = self:mkButton("撤销", w, function()
        p:undo()
    end)
    self.refresh_btn = self:mkButton("刷新", w, function()
        p:fullRefresh()
    end)
    self.save_btn = self:mkButton("导出", w, function()
        p:exportPagePng()
    end)
    -- 虚浮窗开着时，这一键是「收起」而不是「把工具栏整个关掉」
    self.hide_btn = self:mkButton(self:hideText(), w, function()
        if p.bar_float then p:collapseBar() else p:setBarShown(false) end
    end)

    local frame = FrameContainer:new{
        background = Blitbuffer.COLOR_WHITE,
        bordersize = Size.border.window,
        radius = Size.radius.window,
        padding = Size.padding.small,
        margin = 0,
        VerticalGroup:new{
            align = "center",
            self.draw_btn,
            self.tool_btn,
            self.width_btn,
            self.beauty_btn,
            self.undo_btn,
            self.refresh_btn,
            self.save_btn,
            self.hide_btn,
        },
    }

    local size = frame:getSize()
    local pad = Size.padding.large
    local default_x = (self.side == "left") and pad
                   or (Screen:getWidth() - size.w - pad)
    local default_y = math.floor((Screen:getHeight() - size.h) / 2)

    self.full_dimen = Geom:new{ x = default_x, y = default_y, w = size.w, h = size.h }
    self.pill_dimen = self:pillDimen()

    local x, y = default_x, default_y
    if self.position and type(self.position.x) == "number"
       and type(self.position.y) == "number" then
        x, y = self:clampPosition(self.position.x, self.position.y)
    end

    self.movable = MovableBar:new{
        frame,
        dimen = Geom:new{ x = default_x, y = default_y, w = size.w, h = size.h },
        on_move = function(movable)
            local moved_x = (movable._orig_x or default_x) + movable._moved_offset_x
            local moved_y = (movable._orig_y or default_y) + movable._moved_offset_y
            local cx, cy = self:clampPosition(moved_x, moved_y)
            if cx ~= moved_x or cy ~= moved_y then
                movable:setMovedOffset(Geom:new{
                    x = cx - default_x,
                    y = cy - default_y,
                })
            end
            p:setBarPosition(cx, cy)
            p:pokeFloatBar()
        end,
    }
    self.movable:setMovedOffset(Geom:new{ x = x - default_x, y = y - default_y })
    self[1] = self.movable

    -- 折叠态：只画右下角那枚小胶囊
    self.collapsed = not not (p and p.bar_float)
    self.dimen = self.collapsed and self.pill_dimen or self.full_dimen
    self.alpha = self.collapsed and PILL_ALPHA or nil
    self.pill_text = TextWidget:new{
        text = "笔",
        face = Font:getFace("smallinfofont", PILL_FONT_SIZE),
        fgcolor = Blitbuffer.COLOR_BLACK,
    }

    -- 右下角「刷新」胶囊：始终显示，独立几何，不随主胶囊收起/展开。
    self.refresh_pill_enabled = not not (p and p.refresh_pill_enabled)
    self.refresh_pill_dimen = self:refreshPillDimen()
    self.refresh_pill_text = TextWidget:new{
        text = "刷",
        face = Font:getFace("smallinfofont", REFRESH_PILL_FONT_SIZE),
        fgcolor = Blitbuffer.COLOR_BLACK,
    }

    self:update(false)
end

--- 切换折叠 / 展开，并把让出的那一块交给下层重绘。
function Toolbar:setCollapsed(on)
    on = on and true or false
    if self.collapsed == on then return end
    local old = self:getVisibleDimen()
    local old_region = Geom:new{ x = old.x, y = old.y, w = old.w, h = old.h }

    self.collapsed = on
    self.dimen = on and self.pill_dimen or self.full_dimen
    self.alpha = on and PILL_ALPHA or nil
    -- 「隐藏 / 收起」这类跟着模式变的按钮文字要跟着换过来
    self:update(false)

    local p = self.plugin
    if p then
        -- 不管是从哪条路径切过来的：收起就撤掉倒计时，展开就重新拨一遍
        if on then p:cancelFloatTask() else p:pokeFloatBar() end
    end
    -- 先让页面把旧区域重画一遍（清掉刚才那一块），再刷自己
    if p and p.ui then UIManager:setDirty(p.ui, "ui", old_region) end
    UIManager:setDirty(self, "ui", self.dimen)
end

function Toolbar:clampPosition(x, y)
    local d = self.full_dimen or self.dimen
    local max_x = math.max(0, Screen:getWidth() - d.w)
    local max_y = math.max(0, Screen:getHeight() - d.h)
    if x < 0 then x = 0 elseif x > max_x then x = max_x end
    if y < 0 then y = 0 elseif y > max_y then y = max_y end
    return x, y
end

function Toolbar:drawText()
    return self.plugin.drawing and "停止" or "书写"
end

function Toolbar:toolText()
    return self.plugin.eraser and "橡皮" or "钢笔"
end

function Toolbar:widthText()
    local labels = { "细", "中", "粗" }
    return labels[self.plugin.pen_width_index] or "中"
end

function Toolbar:beautyText()
    return self.plugin.beautify and "美化" or "美化×"
end

function Toolbar:hideText()
    return self.plugin.bar_float and "收起" or "隐藏"
end

function Toolbar:getVisibleDimen()
    if self.collapsed then return self.pill_dimen or self.dimen end
    if not self.movable then return self.dimen end
    local d = self.movable.dimen
    -- MovableContainer 在绘制时才更新 dimen，拖动过程中偏移已变，这里补上，
    -- 保证拖动尚未重绘时命中测试依然准确。
    d.x = (self.movable._orig_x or self.dimen.x) + (self.movable._moved_offset_x or 0)
    d.y = (self.movable._orig_y or self.dimen.y) + (self.movable._moved_offset_y or 0)
    return d
end

function Toolbar:getSize()
    return self.dimen
end

function Toolbar:paintTo(bb, x, y)
    if self.collapsed then
        self:paintPill(bb)
    else
        self.movable:paintTo(bb, self.full_dimen.x, self.full_dimen.y)
    end
    -- 刷新胶囊始终显示（折叠态和展开态都画）
    self:paintRefreshPill(bb)
end

--- 刷新按钮文字；refresh=true 时顺带重绘工具栏区域。
function Toolbar:update(refresh)
    self.draw_btn:setText(self:drawText(), self.button_width)
    self.tool_btn:setText(self:toolText(), self.button_width)
    self.width_btn:setText(self:widthText(), self.button_width)
    self.beauty_btn:setText(self:beautyText(), self.button_width)
    self.hide_btn:setText(self:hideText(), self.button_width)
    if refresh then
        UIManager:setDirty(self, "ui", self:getVisibleDimen())
    end
end

--- (x, y) 是否落在工具栏上。slop 是四周的命中余量，手指点小胶囊时用得上。
function Toolbar:contains(x, y, slop)
    local d = self:getVisibleDimen()
    local s = slop or 0
    return x >= d.x - s and x < d.x + d.w + s
       and y >= d.y - s and y < d.y + d.h + s
end

--- (x, y) 是否落在右下角「刷新」胶囊上。
function Toolbar:containsRefresh(x, y, slop)
    if not self.refresh_pill_enabled or not self.refresh_pill_dimen then return false end
    local d = self.refresh_pill_dimen
    local s = slop or 0
    return x >= d.x - s and x < d.x + d.w + s
       and y >= d.y - s and y < d.y + d.h + s
end

-- -------------------------------------------------------------- 事件转发

--- 若没有工具栏，本该接收输入的那个窗口（阅读器，或其上打开的菜单/对话框）。
function Toolbar:windowBelow()
    local stack = UIManager._window_stack
    for i = #stack, 1, -1 do
        local widget = stack[i].widget
        if widget ~= self and not widget.toast then return widget end
    end
end

--[[--
折叠态：点小胶囊唤出完整工具栏；其余一律吞掉（不让它们翻页）。
展开态：落在工具栏上但没点中按钮的手势也吞掉，否则会翻页。

刷新胶囊优先级最高：只要点中它（无论折叠/展开），就立即整屏刷新。
]]
function Toolbar:onGesture(ges)
    local x, y = ges.pos.x, ges.pos.y
    -- 刷新胶囊优先
    if self:containsRefresh(x, y, Screen:scaleBySize(TOUCH_SLOP)) then
        local p = self.plugin
        if p and p.refresh_tap_refreshes then p:fullRefresh() end
        return true
    end
    if not self:contains(x, y) then return end
    local p = self.plugin
    if self.collapsed then
        -- 点「笔」胶囊：展开工具栏，同时整屏刷新一次（清掉书写攒下的残影）
        if p then
            p:expandBar()
            p:fullRefresh()
        end
        return true
    end
    if p then p:pokeFloatBar() end
    return true
end

--[[--
工具栏自己不处理的输入交给下层窗口。

UIManager:sendEvent 只把输入事件交给最上面那个非 toast 的窗口，若这里简单
返回 false，阅读器以及其下方打开的菜单就彻底收不到事件了。

折叠态下按钮都是看不见的，所以事件根本不下发给子控件 —— 否则拖动过工具栏的
话，右下角那一下有可能点到「隐形」的按钮上。
]]
function Toolbar:handleEvent(event)
    if self.collapsed then
        if event.handler == "onGesture" then
            if self:onGesture(unpack(event.args or {})) then return true end
        end
        if INPUT_HANDLERS[event.handler] then
            local below = self:windowBelow()
            if below then return below:handleEvent(event) end
        end
        return false
    end
    if WidgetContainer.handleEvent(self, event) then return true end
    if INPUT_HANDLERS[event.handler] then
        local below = self:windowBelow()
        if below then return below:handleEvent(event) end
    end
end

return Toolbar
