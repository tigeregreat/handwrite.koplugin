--[[--
按页保存笔迹。

    pages = { [页码] = { stroke, stroke, ... } }

整张表会直接写进 KOReader 的 sidecar（.sdr/metadata.*.lua），所以里面只能有
数字和普通数组，不能放函数、userdata 或循环引用。
]]

local Store = {}
Store.__index = Store

function Store.new(pages)
    return setmetatable({ pages = pages or {} }, Store)
end

function Store:get(page)
    return self.pages[page]
end

function Store:count(page)
    local list = self.pages[page]
    return list and #list or 0
end

function Store:add(page, stroke)
    local list = self.pages[page]
    if not list then
        list = {}
        self.pages[page] = list
    end
    list[#list + 1] = stroke
end

--- 弹出并返回某页最后一笔，没有则返回 nil。
function Store:pop(page)
    local list = self.pages[page]
    if not list then return nil end
    local n = #list
    if n == 0 then return nil end
    local s = list[n]
    list[n] = nil
    if n == 1 then self.pages[page] = nil end
    return s
end

function Store:removeAt(page, idx)
    local list = self.pages[page]
    if not list or not list[idx] then return false end
    table.remove(list, idx)
    if #list == 0 then self.pages[page] = nil end
    return true
end

function Store:clearPage(page)
    if not self.pages[page] then return false end
    self.pages[page] = nil
    return true
end

function Store:clearAll()
    self.pages = {}
end

function Store:isEmpty()
    return next(self.pages) == nil
end

--- 有笔迹的页码，升序。
function Store:pageList()
    local pages = {}
    for page in pairs(self.pages) do
        pages[#pages + 1] = page
    end
    table.sort(pages)
    return pages
end

function Store:countPages()
    local n = 0
    for _ in pairs(self.pages) do n = n + 1 end
    return n
end

function Store:countStrokes()
    local n = 0
    for _, list in pairs(self.pages) do
        n = n + #list
    end
    return n
end

--[[--
返回 (x, y) 半径 r 内最上面一笔的下标，没有则 nil。

按「点」判断而不是按线段判断：速度足够快，且手指/橡皮本来也是圆的。
从后往前找，符合「擦掉最上面那笔」的直觉。
]]
function Store.hit(list, x, y, r)
    if not list then return nil end
    local r2 = r * r
    for i = #list, 1, -1 do
        local s = list[i]
        for j = 1, s.n * 2, 2 do
            local dx = s[j] - x
            local dy = s[j + 1] - y
            if dx * dx + dy * dy <= r2 then return i end
        end
    end
    return nil
end

return Store
