--[[--
触摸捕获层。

KOReader 至今没有公开的「原始触点」 API，唯一与设备无关、能看到手指按下/
移动/抬起的地方是 GestureDetector:feedEvent(tevs)。这里把该函数包一层：
  * 原始函数照常调用，手势探测器自身状态不会错乱；
  * 但我们能决定它算出来的手势事件是否继续往应用层传（吞掉 = 不翻页）。

tevs 中每个元素形如 { slot = 0, id = 46, x = 123, y = 456 }：
  * id >= 0 且有 x/y：触点按下或移动
  * id == -1：该触点抬起
坐标是「旋转前」的原始坐标，需要自己按当前屏幕方向换算，见 toScreen()。

只在书写模式开启期间安装，退出时务必 remove()，避免影响正常阅读。
]]

local Device = require("device")
local logger = require("logger")

local Capture = {
    installed = false,
    original = nil,
}

--- 安装钩子。handler(slots) 返回 true = 放行手势，false = 吞掉。
function Capture:install(handler)
    if self.installed then return true end

    local gd = Device.input and Device.input.gesture_detector
    if not (gd and gd.feedEvent) then
        logger.warn("handwrite: 找不到 gesture_detector，无法接管触摸")
        return false
    end

    local original = gd.feedEvent
    self.original = original

    gd.feedEvent = function(gd_self, slots)
        local ok, emit = pcall(handler, slots)
        if not ok then
            -- 出错时一律放行，保证设备不会被卡死在无法操作的状态
            logger.warn("handwrite: 触摸处理出错：", emit)
            emit = true
        end
        local evs = original(gd_self, slots)
        if emit ~= false then return evs end
        for i = #evs, 1, -1 do
            evs[i] = nil
        end
        return evs
    end

    self.installed = true
    return true
end

function Capture:remove()
    if not self.installed then return end
    local gd = Device.input and Device.input.gesture_detector
    if gd and self.original then
        gd.feedEvent = self.original
    end
    self.original = nil
    self.installed = false
end

--[[--
把原始触点坐标换算成屏幕坐标。

GestureDetector 是在「判定之后」才做旋转变换的，所以拿到的原始坐标必须自己
按当前方向换算，否则竖屏/横屏切换后笔迹会错位。
]]
function Capture.toScreen(x, y)
    local screen = Device.screen
    local mode = screen:getRotationMode()
    if mode == screen.DEVICE_ROTATED_UPRIGHT then
        return x, y
    elseif mode == screen.DEVICE_ROTATED_CLOCKWISE then
        return screen:getWidth() - y, x
    elseif mode == screen.DEVICE_ROTATED_UPSIDE_DOWN then
        return screen:getWidth() - x, screen:getHeight() - y
    else -- DEVICE_ROTATED_COUNTER_CLOCKWISE
        return y, screen:getHeight() - x
    end
end

return Capture
